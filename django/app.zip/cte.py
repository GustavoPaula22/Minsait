# -*- coding: utf-8 -*-
# app/cte.py
from __future__ import annotations

import argparse
import json
import os
from typing import Dict, Optional, Tuple, List

from pyspark.sql import DataFrame, SparkSession, Window
from pyspark.sql import functions as F
from pyspark.sql import types as T

from app.settings import Settings, load_settings_from_env, build_spark, print_settings
from app.utils.io import write_df, read_oracle_table
from app.utils.audit import start_and_get_id, bump_counts, finish_success, finish_error

# =============================================================================
# Constantes específicas do CT-e
# =============================================================================
CTE_MODELO = "57"                # Modelo fiscal CT-e
TIPO_DOC_PARTCT_CTE = 20         # <- ajuste se no Django for outro código (no NFe usei 10)
TIPO_DOCUMENTO_FISCAL_CTE = "57" # campo de saída "tipo_documento_fiscal"

# =============================================================================
# Helpers de qualificação / leitura Kudu
# =============================================================================
def _qualify_kudu_table(db: str, name: str, *, for_format: str = "kudu") -> str:
    n = (name or "").strip()
    if n.lower().startswith("impala::"):
        n = n.split("::", 1)[1]
    elif n.lower().startswith("kudu."):
        n = ".".join(n.split(".", 2)[1:])
    if "." not in n:
        n = f"{db}.{n}"
    if for_format.lower() in ("kudu", "impala"):
        return f"impala::{n}"
    return n


def _mk_kudu_between_where(
    data_inicio: str, data_fim: str, chave: Optional[str] = None, ts_col: str = "ide_dhemi_nums"
) -> str:
    di = f"{data_inicio.strip()} 00:00:00"
    df = f"{data_fim.strip()} 23:59:59"
    base = f"{ts_col} BETWEEN unix_timestamp('{di}') AND unix_timestamp('{df}')"
    if chave:
        # em projetos CT-e a chave costuma ser 'chavecte' (ajuste em Settings caso use outro nome)
        base += f" AND chavecte = '{chave.strip()}'"
    return base


def _merge_where(base_where: Optional[str], extra_where: Optional[str]) -> Optional[str]:
    if base_where and extra_where:
        return f"({base_where}) AND ({extra_where})"
    return base_where or extra_where


def _read_kudu(
    spark: SparkSession,
    settings: Settings,
    table_name: str,
    *,
    where: Optional[str],
    columns: Optional[List[str]] = None,
) -> DataFrame:
    kudu_fmt = os.getenv("KUDU_FORMAT", "kudu")
    qualified = _qualify_kudu_table(settings.kudu.database, table_name, for_format=kudu_fmt)
    masters = os.getenv("KUDU_MASTERS", settings.kudu.masters)
    print(f"[cte] KUDU READ | format={kudu_fmt} | masters={masters} | kudu.table={qualified}")

    reader = (
        spark.read.format(kudu_fmt)
        .option("kudu.master", masters)
        .option("kudu.table", qualified)
        .option("kudu.faultTolerantScan", "false")
        .option("kudu.scanLocality", "leader_only")
        .option("kudu.readMode", "READ_LATEST")
        .option("kudu.scanRequestTimeoutMs", "600000")
        .option("kudu.operationTimeoutMs", "180000")
        .option("kudu.socketReadTimeoutMs", "180000")
        .option("kudu.keepAlivePeriodMs", "15000")
    )
    df = reader.load()
    if where:
        print(f"[cte] KUDU WHERE (pushdown): {where}")
        df = df.where(where)
    if columns:
        keep = [c for c in columns if c in df.columns]
        if keep:
            df = df.select(*keep)
    return df

# =============================================================================
# Utils
# =============================================================================
def _digits_only(col: F.Column) -> F.Column:
    return F.regexp_replace(F.trim(col.cast("string")), r"\D", "")

def _str_upper(col: F.Column) -> F.Column:
    return F.upper(F.trim(col.cast("string")))

def _safe_count(df: DataFrame, *, kind: str = "count") -> int:
    try:
        return int(df.count())
    except Exception as e:
        msg = str(e)
        if ("Tablet is lagging too much" in msg) or ("SERVICE_UNAVAILABLE" in msg):
            print(f"[cte][WARN] Kudu instável em {kind}; usando -1. Detalhe: {msg[:300]}")
            return -1
        raise

def _coalesce_doc_number(cnpj: F.Column, cpf: F.Column) -> F.Column:
    return F.coalesce(_digits_only(cnpj), _digits_only(cpf))

def _uf_from_cuf_expr(colname: str) -> F.Column:
    return (
        F.when(F.col(colname) == 11, "RO").when(F.col(colname) == 12, "AC")
        .when(F.col(colname) == 13, "AM").when(F.col(colname) == 14, "RR")
        .when(F.col(colname) == 15, "PA").when(F.col(colname) == 16, "AP")
        .when(F.col(colname) == 17, "TO").when(F.col(colname) == 21, "MA")
        .when(F.col(colname) == 22, "PI").when(F.col(colname) == 23, "CE")
        .when(F.col(colname) == 24, "RN").when(F.col(colname) == 25, "PB")
        .when(F.col(colname) == 26, "PE").when(F.col(colname) == 27, "AL")
        .when(F.col(colname) == 28, "SE").when(F.col(colname) == 29, "BA")
        .when(F.col(colname) == 31, "MG").when(F.col(colname) == 32, "ES")
        .when(F.col(colname) == 33, "RJ").when(F.col(colname) == 35, "SP")
        .when(F.col(colname) == 41, "PR").when(F.col(colname) == 42, "SC")
        .when(F.col(colname) == 43, "RS").when(F.col(colname) == 50, "MS")
        .when(F.col(colname) == 51, "MT").when(F.col(colname) == 52, "GO")
        .when(F.col(colname) == 53, "DF").otherwise(F.lit(None))
    )

def _add_missing_cols(df: DataFrame, names: List[str]) -> DataFrame:
    cur = df
    for c in names:
        if c not in cur.columns:
            cur = cur.withColumn(c, F.lit(None))
    return cur

def _align_df_to_iceberg_table(
    spark: SparkSession,
    settings: Settings,
    df: DataFrame,
    *,
    table_name: str,
    namespace: Optional[str] = None,
) -> DataFrame:
    ns = namespace or settings.iceberg.namespace
    full = f"{settings.iceberg.catalog}.{ns}.{table_name}"
    try:
        target = spark.table(full).schema
    except Exception as e:
        print(f"[align][cte] Não foi possível carregar schema de {full}. Prosseguindo sem alinhamento. Detalhe: {e}")
        return df
    cols_lower = {c.lower(): c for c in df.columns}
    cur = df
    for f in target.fields:
        tgt = f.name
        src = cols_lower.get(tgt.lower())
        if src is None:
            cur = cur.withColumn(tgt, F.lit(None).cast(f.dataType))
        else:
            if src != tgt:
                cur = cur.withColumnRenamed(src, tgt)
            cur = cur.withColumn(tgt, F.col(tgt).cast(f.dataType))
    cur = cur.select(*[f.name for f in target.fields])
    return cur

# =============================================================================
# Leitura Kudu (CT-e)
# Espera-se que os nomes das tabelas venham do Settings:
#   settings.kudu.cte_ident_table, settings.kudu.cte_emit_table, settings.kudu.cte_tomador_table,
#   settings.kudu.cte_valores_table (ou similar).
# Ajuste os nomes nas suas configs se necessário.
# =============================================================================
def _load_ident_cte(
    spark: SparkSession, settings: Settings, *, data_inicio: str, data_fim: str, chavecte: Optional[str], where_extra: Optional[str] = None
) -> DataFrame:
    where_range = _merge_where(_mk_kudu_between_where(data_inicio, data_fim, chavecte, ts_col="ide_dhemi_nums"), where_extra)
    cols = [
        "chavecte", "ide_dhemi_nums",
        "ide_cuf", "ide_tpamb", "ide_mod",
        # emis / tomador possivelmente aqui também dependendo do layout
        "emit_cnpj", "emit_cpf",
        "tom_cnpj", "tom_cpf",
    ]
    df = _read_kudu(spark, settings, settings.kudu.cte_ident_table, where=where_range, columns=cols)
    # filtra modelo 57 e ambiente 1 (produção)
    df = df.filter((F.col("ide_mod").cast("string") == F.lit(CTE_MODELO)) & (F.col("ide_tpamb").cast("string") == F.lit("1")))
    return df

def _load_emit_cte(
    spark: SparkSession, settings: Settings, *, data_inicio: str, data_fim: str, chavecte: Optional[str], where_extra: Optional[str] = None
) -> DataFrame:
    return _read_kudu(
        spark, settings, settings.kudu.cte_emit_table,
        where=_merge_where(_mk_kudu_between_where(data_inicio, data_fim, chavecte, ts_col="ide_dhemi_nums"), where_extra),
    )

def _load_tomador_cte(
    spark: SparkSession, settings: Settings, *, data_inicio: str, data_fim: str, chavecte: Optional[str], where_extra: Optional[str] = None
) -> DataFrame:
    # Em muitos datasets de CT-e, o tomador está numa tabela "tom" ou "dest" com UF/IE/mun
    return _read_kudu(
        spark, settings, settings.kudu.cte_tomador_table,
        where=_merge_where(_mk_kudu_between_where(data_inicio, data_fim, chavecte, ts_col="ide_dhemi_nums"), where_extra),
    )

def _load_valores_cte(
    spark: SparkSession, settings: Settings, *, data_inicio: str, data_fim: str, chavecte: Optional[str], where_extra: Optional[str] = None
) -> DataFrame:
    # valores do CT-e: vPrest (total do serviço), vRec, vDesc, etc.
    return _read_kudu(
        spark, settings, settings.kudu.cte_valores_table,
        where=_merge_where(_mk_kudu_between_where(data_inicio, data_fim, chavecte, ts_col="ide_dhemi_nums"), where_extra),
    )

# =============================================================================
# Preparação de documentos CT-e
# =============================================================================
def _prepare_docs_cte(
    spark: SparkSession, settings: Settings, *,
    data_inicio: str, data_fim: str, chavecte: Optional[str], where_docs: Optional[str]
) -> DataFrame:
    ident = _load_ident_cte(spark, settings, data_inicio=data_inicio, data_fim=data_fim, chavecte=chavecte, where_extra=where_docs)
    emit  = _load_emit_cte(spark, settings, data_inicio=data_inicio, data_fim=data_fim, chavecte=chavecte, where_extra=where_docs)
    tom   = _load_tomador_cte(spark, settings, data_inicio=data_inicio, data_fim=data_fim, chavecte=chavecte, where_extra=where_docs)
    vals  = _load_valores_cte(spark, settings, data_inicio=data_inicio, data_fim=data_fim, chavecte=chavecte, where_extra=where_docs)

    # Seleções tolerantes a schema (usa alias só se existir)
    emit_sel = []
    for c in ["chavecte", "uf", "ie", "cmun", "cnpj", "cpf"]:
        if c in emit.columns:
            emit_sel.append(c)
    emit = emit.select(*emit_sel) if emit_sel else emit.select("chavecte")

    tom_sel = []
    for c in ["chavecte", "uf", "ie", "cmun", "cnpj", "cpf"]:
        if c in tom.columns:
            tom_sel.append(c)
    tom = tom.select(*tom_sel) if tom_sel else tom.select("chavecte")

    vals_sel_map = {
        # nomes comuns em CT-e; ajuste se no seu Kudu tiver outro naming
        "vprest": "vprest",
        "vrec":   "vrec",
        "vdesc":  "vdesc",
        "vtot":   "vtot",
    }
    keep_vals = [c for c in vals_sel_map if c in vals.columns]
    if keep_vals:
        vals = vals.select("chavecte", *keep_vals)
    else:
        vals = vals.select("chavecte")

    docs = (
        ident.alias("i")
        .join(emit.alias("e"), on="chavecte", how="left")
        .join(tom.alias("t"), on="chavecte", how="left")
        .join(vals.alias("v"), on="chavecte", how="left")
    )

    # Datas
    docs = (
        docs.withColumn("data_emissao_dt", F.to_date(F.from_unixtime(F.col("i.ide_dhemi_nums").cast("bigint"))))
            .withColumn("data_emissao_ts", F.to_timestamp(F.from_unixtime(F.col("i.ide_dhemi_nums").cast("bigint"))))
            .withColumn("i_uf_from_cuf", _uf_from_cuf_expr("i.ide_cuf"))
    )

    # CNPJs participantes
    docs = (
        docs.withColumn("emit_doc_ident", _coalesce_doc_number(F.col("i.emit_cnpj"), F.col("i.emit_cpf")))
            .withColumn("tom_doc_ident",  _coalesce_doc_number(F.col("i.tom_cnpj"),  F.col("i.tom_cpf")))
    )

    # Determina lado (GO como emissor = saída; GO como tomador = entrada)
    emit_uf = F.upper(F.col("e.uf")) if "uf" in emit.columns else F.lit(None)
    tom_uf  = F.upper(F.col("t.uf")) if "uf" in tom.columns else F.lit(None)

    docs = docs.withColumn("emit_uf", emit_uf).withColumn("tom_uf", tom_uf)

    GO = F.lit("GO")
    lado_go = (
        F.when((F.col("emit_uf") == GO) | (F.col("emit_uf").isNull() & (F.col("i_uf_from_cuf") == GO)), F.lit("EMIT"))
         .when(F.col("tom_uf") == GO, F.lit("TOM"))
         .otherwise(F.lit(None))
    )
    docs = docs.withColumn("lado_go", lado_go).filter(F.col("lado_go").isNotNull())
    docs = docs.withColumn("tipo_doc_go", F.when(F.col("lado_go") == F.lit("EMIT"), F.lit("1")).otherwise(F.lit("0")))

    # IBGE/UF (cad/doc) – tentamos usar colunas se existirem; se não, deixamos nulo
    docs = _add_missing_cols(docs, [
        "e.cmun" if "cmun" in emit.columns else "dummy1",
        "t.cmun" if "cmun" in tom.columns else "dummy2",
        "e.ie"   if "ie"   in emit.columns else "dummy3",
        "t.ie"   if "ie"   in tom.columns else "dummy4",
    ])

    docs = (
        docs
        # ENTRADA (tomador)
        .withColumn("cad_entrada_docnum", F.col("tom_doc_ident"))
        .withColumn("cad_entrada_ie", F.col("t.ie") if "ie" in tom.columns else F.lit(None))
        .withColumn("cad_entrada_ie_digits", _digits_only(F.col("t.ie") if "ie" in tom.columns else F.lit(None)))
        .withColumn("cad_entrada_cmun_ibge_str", _digits_only(F.col("t.cmun") if "cmun" in tom.columns else F.lit(None)))
        .withColumn("cad_entrada_uf_src", F.upper(F.col("tom_uf")))
        # SAÍDA (emitente)
        .withColumn("cad_saida_docnum", F.col("emit_doc_ident"))
        .withColumn("cad_saida_ie", F.col("e.ie") if "ie" in emit.columns else F.lit(None))
        .withColumn("cad_saida_ie_digits", _digits_only(F.col("e.ie") if "ie" in emit.columns else F.lit(None)))
        .withColumn("cad_saida_cmun_ibge_str", _digits_only(F.col("e.cmun") if "cmun" in emit.columns else F.lit(None)))
        .withColumn("cad_saida_uf_src", F.upper(F.col("emit_uf")))
    )

    # Valor do documento (preferência vPrest; fallback vTot/vRec - vDesc)
    vl = F.coalesce(
        F.col("v.vprest").cast("decimal(17,2)"),
        (F.col("v.vtot") - F.coalesce(F.col("v.vdesc"), F.lit(0))).cast("decimal(17,2)") if ("vtot" in vals.columns) else None,
        F.col("v.vrec").cast("decimal(17,2)") if ("vrec" in vals.columns) else None,
    )
    docs = docs.withColumn("vl_cte", vl)

    # Flags padrão (em CT-e você pode ter cancelamento/substituição via eventos; mantenho booleans como no NFe)
    docs = (
        docs.withColumn("is_cancelado",   F.lit(False).cast("boolean"))
            .withColumn("is_substituido", F.lit(False).cast("boolean"))
            .withColumn("has_inutil",     F.lit(False).cast("boolean"))
            .withColumn("has_cce",        F.lit(False).cast("boolean"))
    )

    return docs

# =============================================================================
# Regras / projeções (Documento CT-e)
# =============================================================================
def _compute_codg_motivo_exclusao_doc_cte(df: DataFrame) -> DataFrame:
    """
    Motivo de exclusão (documento):
      10 = cancelado
      13 = substituído
       0 = participante (por ora, CT-e não tem regra de item participante como NFe)
    """
    return df.withColumn(
        "codg_motivo_exclusao_doc",
        F.when(F.col("is_cancelado") == True, F.lit(10))
         .when(F.col("is_substituido") == True, F.lit(13))
         .otherwise(F.lit(0))
    ).withColumn(
        "indi_aprop_doc", F.when(F.col("codg_motivo_exclusao_doc") == F.lit(0), F.lit("S")).otherwise(F.lit("N"))
    ).withColumn(
        "valr_adicionado_doc", F.when(F.col("codg_motivo_exclusao_doc") == F.lit(0), F.col("vl_cte")).otherwise(F.lit(0.0))
    )

def _project_document_ipm_cte(
    spark: SparkSession, settings: Settings, docs_part: DataFrame, audit_id: Optional[int]
) -> DataFrame:
    # Detectar precisão dos IBGE no Iceberg, se necessário (usando tabela CT-e)
    def _detect_digits(field_name: str, default: int = 6) -> int:
        full = f"{settings.iceberg.catalog}.{settings.iceberg.namespace}.{settings.iceberg.tbl_cte_documento_partct}"
        try:
            schema = spark.table(full).schema
            f = next((x for x in schema.fields if x.name.lower() == field_name.lower()), None)
            if f and isinstance(f.dataType, T.DecimalType):
                return 7 if getattr(f.dataType, "precision", 6) >= 7 else 6
        except Exception as e:
            print(f"[proj][cte] Não detectei {field_name} em {full}: {e}. Usando {default}.")
        return default

    def _cast_ibge(scol: str, digits: int) -> F.Column:
        return _digits_only(F.col(scol)).cast(f"decimal({digits},0)")

    ent_digits = _detect_digits("codg_municipio_entrada_cad", 6)
    sai_digits = _detect_digits("codg_municipio_saida_cad", 6)

    docs = docs_part.withColumn("numr_ref_aaaamm", F.date_format(F.col("data_emissao_dt"), "yyyyMM").cast("int"))

    out = docs.select(
        F.col("chavecte").alias("codg_chave_acesso_nfe"),  # mantenho o mesmo nome de coluna alvo do IPM (compat)
        F.lit(TIPO_DOCUMENTO_FISCAL_CTE).alias("tipo_documento_fiscal"),
        # ENTRADA (tomador)
        F.col("cad_entrada_docnum").alias("numr_cpf_cnpj_entrada"),
        F.col("cad_entrada_ie").cast("decimal(15,0)").alias("numr_inscricao_entrada"),
        F.lit(None).alias("stat_cadastro_entrada"),
        F.lit(None).alias("tipo_enqdto_fiscal_entrada"),
        F.lit(None).alias("indi_prod_rural_entrada"),
        F.lit(None).alias("indi_prod_rural_exclus_entrada"),
        _cast_ibge("cad_entrada_cmun_ibge_str", ent_digits).alias("codg_municipio_entrada_cad"),
        F.col("cad_entrada_uf_src").alias("codg_uf_entrada_cad"),
        _cast_ibge("cad_entrada_cmun_ibge_str", 7).alias("codg_municipio_entrada_doc"),
        F.col("cad_entrada_uf_src").alias("codg_uf_entrada_doc"),
        # SAÍDA (emitente)
        F.col("cad_saida_docnum").alias("numr_cpf_cnpj_saida"),
        F.col("cad_saida_ie").cast("decimal(14,0)").alias("numr_inscricao_saida"),
        F.lit(None).alias("stat_cadastro_saida"),
        F.lit(None).alias("tipo_enqdto_fiscal_saida"),
        F.lit(None).alias("indi_prod_rural_saida"),
        F.lit(None).alias("indi_prod_rural_exclus_saida"),
        _cast_ibge("cad_saida_cmun_ibge_str", sai_digits).alias("codg_municipio_saida_cad"),
        F.col("cad_saida_uf_src").alias("codg_uf_saida_cad"),
        _cast_ibge("cad_saida_cmun_ibge_str", 7).alias("codg_municipio_saida_doc"),
        F.col("cad_saida_uf_src").alias("codg_uf_saida_doc"),
        # datas/valores
        F.col("data_emissao_dt").alias("data_emissao_nfe"),
        F.col("vl_cte").cast("decimal(17,2)").alias("valr_nota_fiscal"),
        # regras doc
        F.col("valr_adicionado_doc").cast("decimal(17,2)").alias("valr_adicionado_operacao"),
        F.col("indi_aprop_doc").alias("indi_aprop"),
        F.lit(TIPO_DOC_PARTCT_CTE).cast("decimal(3,0)").alias("codg_tipo_doc_partct_calc"),
        F.col("codg_motivo_exclusao_doc").cast("decimal(2,0)").alias("codg_motivo_exclusao_calculo"),
        # referência e auditoria
        F.col("numr_ref_aaaamm").cast("decimal(6,0)").alias("numr_referencia_documento"),
        F.lit(int(audit_id) if audit_id is not None else None).cast("decimal(9,0)").alias("id_procesm_indice"),
    )
    return out

# =============================================================================
# Pipeline principal (CT-e)
# =============================================================================
def run_cte(
    spark: SparkSession,
    settings: Settings,
    *,
    data_inicio: str,
    data_fim: str,
    where_docs: Optional[str],
    prefer_day_partition: bool = False,
    audit_params: Optional[Dict] = None,
    audit_enabled: bool = True,
    chavecte: Optional[str] = None,
) -> Dict[str, int]:
    metrics: Dict[str, int] = {}

    audit_id = None
    if audit_enabled:
        params_json = json.dumps(
            audit_params
            or {
                "fonte": "KUDU",
                "prefer_day_partition": prefer_day_partition,
                "range_where": _mk_kudu_between_where(data_inicio, data_fim, chavecte),
                "where_docs": where_docs,
            },
            ensure_ascii=False,
        )
        audit_id = start_and_get_id(
            spark, settings, documento="CTE",
            data_inicio=data_inicio, data_fim=data_fim, params_json=params_json,
        )
        metrics["audit_id"] = audit_id

    try:
        print(f"[cte][oracle] DSN efetivo -> {settings.oracle.dsn}")

        # Base documentos
        df_docs_base = _prepare_docs_cte(
            spark, settings,
            data_inicio=data_inicio, data_fim=data_fim, chavecte=chavecte, where_docs=where_docs
        ).persist()

        metrics["docs_lidos"] = _safe_count(df_docs_base, kind="docs_lidos")

        if audit_enabled and audit_id is not None:
            bump_counts(spark, settings, id_procesm_indice=audit_id, add_docs=metrics["docs_lidos"], add_itens=0)

        # Regras doc
        df_docs_rules = _compute_codg_motivo_exclusao_doc_cte(df_docs_base)

        # Participantes
        df_docs_part = df_docs_rules.filter(F.col("codg_motivo_exclusao_doc") == F.lit(0)).cache()
        metrics["docs_participantes"] = _safe_count(df_docs_part, kind="docs_participantes")

        # Projeções
        df_docs_out = _project_document_ipm_cte(spark, settings, df_docs_part, audit_id=audit_id)

        # Alinhamento e escrita (tabela de documentos CT-e no Iceberg)
        df_docs_out = _align_df_to_iceberg_table(
            spark, settings, df_docs_out,
            table_name=settings.iceberg.tbl_cte_documento_partct, namespace=settings.iceberg.namespace,
        )
        metrics["docs_finais"] = _safe_count(df_docs_out, kind="docs_finais")

        write_df(
            df_docs_out, settings=settings, output_format="iceberg",
            table_name=settings.iceberg.tbl_cte_documento_partct,
            mode=settings.partitioning.mode_documento, partition_by=None, namespace=settings.iceberg.namespace,
        )

        # Itens CT-e: normalmente não existem “itens” como NFe; se houver uma tabela-alvo de itens,
        # você pode gerar linhas derivadas (ex.: componentes de vPrest). Aqui tentamos escrever vazio,
        # apenas para manter compatibilidade se a tabela existir.
        try:
            empty_items = spark.createDataFrame([], spark.table(
                f"{settings.iceberg.catalog}.{settings.iceberg.namespace}.{settings.iceberg.tbl_cte_item_documento}"
            ).schema)
            write_df(
                empty_items, settings=settings, output_format="iceberg",
                table_name=settings.iceberg.tbl_cte_item_documento,
                mode=settings.partitioning.mode_item, partition_by=None, namespace=settings.iceberg.namespace,
            )
            metrics["itens_finais"] = 0
        except Exception as _:
            print("[cte] Tabela de itens CT-e não configurada; pulando escrita de itens.")
            metrics["itens_finais"] = 0

        if audit_enabled and audit_id is not None:
            finish_success(
                spark, settings, id_procesm_indice=audit_id,
                extra_updates={"qtd_docs": metrics["docs_finais"], "qtd_itens": metrics["itens_finais"]},
            )
        return metrics

    except Exception as e:
        if audit_enabled and audit_id is not None:
            finish_error(spark, settings, id_procesm_indice=audit_id, erro_msg=str(e))
        raise

# =============================================================================
# CLI
# =============================================================================
def _parse_bool(v: str) -> bool:
    return str(v).strip().lower() in {"1", "true", "t", "y", "yes", "sim", "s"}

def parse_args(argv=None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Pipeline CT-e (Kudu -> Iceberg)")
    p.add_argument("--data-inicio", required=True, help="AAAA-MM-DD")
    p.add_argument("--data-fim", required=True, help="AAAA-MM-DD")
    p.add_argument("--where-docs", default=None)
    p.add_argument("--prefer-day-partition", default="false")
    p.add_argument("--print-settings", default="false")
    p.add_argument("--no-audit", action="store_true")
    p.add_argument("--chavecte", default=None)
    return p.parse_args(argv)

def main(argv=None) -> None:
    settings = load_settings_from_env()
    spark = build_spark(settings)
    args = parse_args(argv)

    prefer_day_partition = _parse_bool(args.prefer_day_partition)

    if _parse_bool(args.print_settings):
        print_settings(settings)

    metrics = run_cte(
        spark,
        settings,
        data_inicio=args.data_inicio,
        data_fim=args.data_fim,
        where_docs=args.where_docs,
        prefer_day_partition=prefer_day_partition,
        audit_params={
            "cli": True,
            "range_where": _mk_kudu_between_where(args.data_inicio, args.data_fim, args.chavecte),
            "where_docs": args.where_docs,
        },
        audit_enabled=(not args.no_audit),
        chavecte=args.chavecte,
    )

    print("=== CT-e Metrics ===")
    for k in sorted(metrics.keys()):
        print(f"{k}: {metrics[k]}")

    spark.stop()

if __name__ == "__main__":
    main()
