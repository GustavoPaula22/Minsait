# -*- coding: utf-8 -*-
# app/efd.py
from __future__ import annotations

import argparse
import json
import os
from typing import Dict, Optional, Tuple

from pyspark.sql import DataFrame, SparkSession, Window
from pyspark.sql import functions as F
from pyspark.sql import types as T

from app.settings import Settings, load_settings_from_env, build_spark, print_settings
from app.utils.io import write_df, read_kudu_table
from app.utils.audit import start_and_get_id, bump_counts, finish_success, finish_error
from app.utils.rules import (
    RulesContext,
    load_params_ref,
    load_cfop_ref,
    load_ncm_ref,
    load_cce_ref,
    load_gen_ref,
    apply_rules_to_items,
    apply_rules_to_documents,
)

# =============================================================================
# Defaults e variáveis de ambiente
# =============================================================================

# Fonte
_DEFAULT_KUDU_DB = os.getenv("EFD_KUDU_DB", "kudu")

# Tabelas Kudu (ajuste conforme seu catálogo; podem ser sobrescritas por CLI)
# Registros de documentos (C100) e itens (C170)
_DEFAULT_TB_C100 = os.getenv("EFD_C100_TABLE", "efd_c100")
_DEFAULT_TB_C170 = os.getenv("EFD_C170_TABLE", "efd_c170")

# Registros de período/ajustes (opcionais)
_DEFAULT_TB_E100 = os.getenv("EFD_E100_TABLE", "efd_e100")   # Período de apuração
_DEFAULT_TB_E110 = os.getenv("EFD_E110_TABLE", "efd_e110")   # Apuração (ajustes/saldos)

# Colunas de pushdown
# Preferência: timestamp numérico (segundos epoch) nas tabelas de doc/item
_DEFAULT_TS_DOC = os.getenv("EFD_TS_DOC_COL", "dt_doc_nums")   # C100
_DEFAULT_TS_ITEM = os.getenv("EFD_TS_ITEM_COL", "dt_doc_nums") # C170 herda a data do doc na maioria dos modelos

# Chave canônica do documento EFD no nosso pipeline
# Se você já tem uma coluna pronta no Kudu (ex.: 'doc_id', 'hash_doc'), informe em --key-col
_DEFAULT_KEY_COL = os.getenv("EFD_KEY_COL", "doc_id")

# Tabelas de saída (por padrão, usamos as mesmas do IPM – você pode sobrescrever)
_DEFAULT_OUT_DOC = os.getenv("EFD_OUT_DOC_TABLE", "")  # vazio = usar settings.iceberg.document_table()
_DEFAULT_OUT_ITEM = os.getenv("EFD_OUT_ITEM_TABLE", "")  # vazio = usar settings.iceberg.item_table()

# =============================================================================
# Helpers
# =============================================================================

def _normalize_table_name(n: str, *, db: Optional[str]) -> str:
    """Permite passar 'tb' ou 'db.tb'; retorna 'impala::db.tb' para o leitor Kudu."""
    if "." not in n and db:
        n = f"{db}.{n}"
    return f"impala::{n}"

def _mk_between_ts(where_col: str, data_inicio: str, data_fim: str) -> str:
    di = f"{data_inicio.strip()} 00:00:00"
    df = f"{data_fim.strip()} 23:59:59"
    return f"{where_col} BETWEEN unix_timestamp('{di}') AND unix_timestamp('{df}')"

def _safe_count(df: Optional[DataFrame], what: str) -> int:
    if df is None:
        return 0
    try:
        return int(df.count())
    except Exception as e:
        print(f"[efd][_safe_count] Falha ao contar {what}: {e}")
        return -1

def _build_doc_id(
    df_c100: DataFrame,
    *,
    key_col: str,
) -> DataFrame:
    """
    Cria uma chave canônica 'doc_id' a partir de C100:
      - Identificação do contribuinte (CNPJ/CPF)
      - Modelo do documento (COD_MOD)
      - Série (SER)
      - Número (NUM_DOC)
      - Data (DT_DOC)
    Ajuste aqui se suas colunas tiverem nomes diferentes.
    """
    # Normaliza strings para evitar null -> 'null' e espaços
    norm = F.udf(lambda x: x.strip() if isinstance(x, str) else x, T.StringType())

    df = (
        df_c100
        .withColumn("cnpj_cpf_norm", F.coalesce(F.col("CNPJ"), F.col("CPF")))
        .withColumn("cnpj_cpf_norm", norm(F.col("cnpj_cpf_norm")))
        .withColumn("cod_mod_norm", norm(F.col("COD_MOD")))
        .withColumn("ser_norm", norm(F.col("SER")))
        .withColumn("num_doc_norm", norm(F.col("NUM_DOC")))
        .withColumn("dt_doc_norm", F.date_format(F.to_date(F.col("DT_DOC")), "yyyy-MM-dd"))
        .withColumn(
            key_col,
            F.concat_ws(
                "|",
                F.coalesce(F.col("cnpj_cpf_norm"), F.lit("")),
                F.coalesce(F.col("cod_mod_norm"), F.lit("")),
                F.coalesce(F.col("ser_norm"), F.lit("")),
                F.coalesce(F.col("num_doc_norm"), F.lit("")),
                F.coalesce(F.col("dt_doc_norm"), F.lit("")),
            ),
        )
        .drop("cnpj_cpf_norm", "cod_mod_norm", "ser_norm", "num_doc_norm", "dt_doc_norm")
    )
    return df

# =============================================================================
# Leitura Kudu (C100 / C170 / E100 / E110)
# =============================================================================

def _read_efd_c100(
    spark: SparkSession,
    settings: Settings,
    *,
    kudu_db: str,
    tb_c100: str,
    ts_col: str,
    data_inicio: str,
    data_fim: str,
) -> DataFrame:
    where_sql = _mk_between_ts(ts_col, data_inicio, data_fim)
    return read_kudu_table(
        spark,
        settings,
        table=_normalize_table_name(tb_c100, db=kudu_db),
        where=where_sql,
        columns=None,
    )

def _read_efd_c170(
    spark: SparkSession,
    settings: Settings,
    *,
    kudu_db: str,
    tb_c170: str,
    ts_col: str,
    data_inicio: str,
    data_fim: str,
) -> DataFrame:
    where_sql = _mk_between_ts(ts_col, data_inicio, data_fim)
    return read_kudu_table(
        spark,
        settings,
        table=_normalize_table_name(tb_c170, db=kudu_db),
        where=where_sql,
        columns=None,
    )

def _read_efd_e100(
    spark: SparkSession,
    settings: Settings,
    *,
    kudu_db: str,
    tb_e100: Optional[str],
    data_inicio: str,
    data_fim: str,
) -> Optional[DataFrame]:
    if not tb_e100:
        return None
    # E100 normalmente tem campos de período (DT_INI, DT_FIN); vamos filtrar por interseção com [inicio,fim]
    where_sql = f"( (unix_timestamp(DT_INI) <= unix_timestamp('{data_fim}')) AND (unix_timestamp(DT_FIN) >= unix_timestamp('{data_inicio}')) )"
    return read_kudu_table(
        spark,
        settings,
        table=_normalize_table_name(tb_e100, db=kudu_db),
        where=where_sql,
        columns=None,
    )

def _read_efd_e110(
    spark: SparkSession,
    settings: Settings,
    *,
    kudu_db: str,
    tb_e110: Optional[str],
    data_inicio: str,
    data_fim: str,
) -> Optional[DataFrame]:
    if not tb_e110:
        return None
    # E110 se relaciona com E100; filtro por período também
    where_sql = f"( (unix_timestamp(DT_INI) <= unix_timestamp('{data_fim}')) AND (unix_timestamp(DT_FIN) >= unix_timestamp('{data_inicio}')) )"
    return read_kudu_table(
        spark,
        settings,
        table=_normalize_table_name(tb_e110, db=kudu_db),
        where=where_sql,
        columns=None,
    )

# =============================================================================
# Regras (lookup Oracle) e aplicação
# =============================================================================

def _load_refs_oracle(spark: SparkSession, settings: Settings) -> RulesContext:
    """
    Carrega referências do Oracle IPM para aplicar regras (sem ETL das auxiliares):
      - Parâmetros de processamento
      - CFOP participante
      - NCM participante
      - Eventos (CCE/Cancelamento/etc.) — quando fizer sentido no cruzamento
      - GEN (municípios / mapeamentos)
    """
    df_params = load_params_ref(spark, settings)
    df_cfop   = load_cfop_ref(spark, settings)
    df_ncm    = load_ncm_ref(spark, settings)
    df_evt    = load_cce_ref(spark, settings)
    df_gen    = load_gen_ref(spark, settings)

    # O RulesContext encapsula essas bases + dicionário de params
    return RulesContext(
        df_params=df_params,
        df_cfop_ref=df_cfop,
        df_ncm_ref=df_ncm,
        df_eventos=df_evt,
        df_gen=df_gen,
        params_dict=None,
    )

# =============================================================================
# Agregação de itens -> documento
# =============================================================================

def _aggregate_items_to_document(
    df_docs: DataFrame,
    df_items_rules: Optional[DataFrame],
    *,
    key_col: str,
) -> DataFrame:
    """
    Agrega dos ITENS (já com regras aplicadas) para o DOCUMENTO:
      - valr_adicionado_operacao: soma dos valr_adicionado por doc
      - indi_aprop: 'S' se houver ao menos 1 item participante por CFOP; senão 'N'
      - codg_tipo_doc_partct: máximo não nulo de codg_tipo_doc_partct_item
    """
    if df_items_rules is None:
        return (
            df_docs
            .withColumn("indi_aprop", F.lit(None).cast("string"))
            .withColumn("valr_adicionado_operacao", F.lit(None).cast(T.DecimalType(17, 2)))
            .withColumn("codg_tipo_doc_partct", F.lit(None).cast("int"))
        )

    grp = (
        df_items_rules
        .groupBy(key_col)
        .agg(
            F.sum(F.coalesce(F.col("valr_adicionado").cast(T.DecimalType(17, 2)), F.lit(0))).alias("valr_adicionado_operacao"),
            F.max(F.when(F.col("is_cfop_participante") == F.lit(True), F.lit(1)).otherwise(F.lit(0))).alias("has_part_item"),
            F.max(F.coalesce(F.col("codg_tipo_doc_partct_item").cast("int"), F.lit(0))).alias("codg_tipo_doc_partct"),
        )
    )

    out = (
        df_docs.join(grp, on=key_col, how="left")
        .withColumn("indi_aprop", F.when(F.col("has_part_item") == 1, F.lit("S")).otherwise(F.lit("N")))
        .drop("has_part_item")
    )
    return out

# =============================================================================
# Projeções finais (layout EFD → IPM)
# =============================================================================

def _project_document_efd(df_docs: DataFrame, *, key_col: str) -> DataFrame:
    """
    Projeção mínima para alinhar com a escrita IPM_DOCUMENTO_PARTCT_CALC_IPM.
    Ajuste os nomes conforme seu projections.py, se já existir mapeamento específico para EFD.
    """
    # Campos essenciais para IPM_DOCUMENTO_PARTCT_CALC_IPM (ex.: CODG_CHAVE_ACESSO_NFE no NFe)
    # Aqui usamos 'doc_id' como chave do documento do EFD.
    cols = {
        "id_procesm_indice": F.lit(None).cast("int"),
        "codg_chave_acesso_nfe": F.col(key_col),  # EFD não tem chave NFe; usamos a chave sintética
        "indi_aprop": F.col("indi_aprop"),
        "valr_adicionado_operacao": F.col("valr_adicionado_operacao").cast(T.DecimalType(17, 2)),
        "codg_tipo_doc_partct": F.col("codg_tipo_doc_partct"),
        # Datas úteis do C100
        "datm_emis_documento": F.to_date(F.col("DT_DOC")),
        "datm_entr_said": F.to_date(F.col("DT_E_S")),
        # Colunas contábeis/fiscais agregadas (ex.: VL_DOC/VL_ICMS, se existirem)
        "vlr_total_documento": F.col("VL_DOC").cast(T.DecimalType(17, 2)) if "VL_DOC" in df_docs.columns else F.lit(None).cast(T.DecimalType(17, 2)),
    }

    select_exprs = [expr.alias(name) for name, expr in cols.items()]
    return df_docs.select(*select_exprs)

def _project_item_efd(df_items: DataFrame, *, key_col: str) -> DataFrame:
    """
    Projeção mínima para alinhar com a escrita IPM_ITEM_DOCUMENTO.
    """
    if df_items is None:
        return None

    cols = {
        "codg_chave_acesso_nfe": F.col(key_col),
        "numr_item": F.col("NUM_ITEM").cast("int") if "NUM_ITEM" in df_items.columns else F.monotonically_increasing_id().cast("int"),
        "cfop": F.col("CFOP"),
        "ncm": F.col("COD_NCM") if "COD_NCM" in df_items.columns else F.col("NCM"),
        "valr_adicionado": F.col("valr_adicionado").cast(T.DecimalType(17, 2)),
        "is_cfop_participante": F.col("is_cfop_participante").cast("boolean"),
        "codg_tipo_doc_partct_item": F.col("codg_tipo_doc_partct_item").cast("int"),
        # Alguns totais úteis (quando existirem em C170)
        "vlr_item": F.col("VL_ITEM").cast(T.DecimalType(17, 2)) if "VL_ITEM" in df_items.columns else F.lit(None).cast(T.DecimalType(17, 2)),
        "qtd_item": F.col("QTD").cast(T.DecimalType(17, 3)) if "QTD" in df_items.columns else F.lit(None).cast(T.DecimalType(17, 3)),
    }

    select_exprs = [expr.alias(name) for name, expr in cols.items()]
    return df_items.select(*select_exprs)

# =============================================================================
# Pipeline principal
# =============================================================================

def run_efd(
    spark: SparkSession,
    settings: Settings,
    *,
    data_inicio: str,
    data_fim: str,
    kudu_db: str = _DEFAULT_KUDU_DB,
    efd_c100_table: str = _DEFAULT_TB_C100,
    efd_c170_table: str = _DEFAULT_TB_C170,
    efd_e100_table: Optional[str] = _DEFAULT_TB_E100,
    efd_e110_table: Optional[str] = _DEFAULT_TB_E110,
    ts_doc_col: str = _DEFAULT_TS_DOC,
    ts_item_col: str = _DEFAULT_TS_ITEM,
    key_col: str = _DEFAULT_KEY_COL,
    out_doc_table: Optional[str] = _DEFAULT_OUT_DOC or None,
    out_item_table: Optional[str] = _DEFAULT_OUT_ITEM or None,
    mode: str = "merge",
    print_settings_flag: bool = False,
    audit_enabled: bool = True,
    write_iceberg: bool = True,
) -> Dict[str, int]:

    if print_settings_flag:
        print_settings(settings)

    audit_id = start_and_get_id(spark, "EFD", enabled=audit_enabled)

    # ---------- Leitura Kudu ----------
    df_c100 = _read_efd_c100(
        spark, settings,
        kudu_db=kudu_db,
        tb_c100=efd_c100_table,
        ts_col=ts_doc_col,
        data_inicio=data_inicio, data_fim=data_fim,
    )

    df_c170 = _read_efd_c170(
        spark, settings,
        kudu_db=kudu_db,
        tb_c170=efd_c170_table,
        ts_col=ts_item_col,
        data_inicio=data_inicio, data_fim=data_fim,
    )

    df_e100 = _read_efd_e100(
        spark, settings,
        kudu_db=kudu_db,
        tb_e100=efd_e100_table,
        data_inicio=data_inicio, data_fim=data_fim,
    )

    df_e110 = _read_efd_e110(
        spark, settings,
        kudu_db=kudu_db,
        tb_e110=efd_e110_table,
        data_inicio=data_inicio, data_fim=data_fim,
    )

    metrics: Dict[str, int] = {}
    metrics["c100_lidos"] = _safe_count(df_c100, "C100")
    metrics["c170_lidos"] = _safe_count(df_c170, "C170")
    metrics["e100_lidos"] = _safe_count(df_e100, "E100")
    metrics["e110_lidos"] = _safe_count(df_e110, "E110")

    # ---------- Chave canônica (doc_id) ----------
    df_docs_base = _build_doc_id(df_c100, key_col=key_col)

    # Vincula doc_id nos itens (C170 deve herdar chaves do C100; usamos join por chaves naturais)
    # Relacionamento típico: C170 herda (IND_OPER, IND_EMIT, COD_PART, COD_MOD, SER, NUM_DOC, DT_DOC, etc.)
    # Usaremos um join por (COD_MOD, SER, NUM_DOC, DT_DOC, CNPJ/CPF) quando disponível.
    join_keys = []
    for k in ("COD_MOD", "SER", "NUM_DOC", "DT_DOC"):
        if k in df_c170.columns and k in df_docs_base.columns:
            join_keys.append(k)
    # Identificação do participante (contribuinte)
    if "CNPJ" in df_c170.columns and "CNPJ" in df_docs_base.columns:
        join_keys.append("CNPJ")
    elif "CPF" in df_c170.columns and "CPF" in df_docs_base.columns:
        join_keys.append("CPF")

    if not join_keys:
        # fallback agressivo: cruzamento por número e data (menos preciso)
        for k in ("NUM_DOC", "DT_DOC"):
            if k in df_c170.columns and k in df_docs_base.columns:
                join_keys.append(k)

    df_items_base = (
        df_c170.join(df_docs_base.select(key_col, *[c for c in join_keys]),
                     on=join_keys, how="left")
    )

    # ---------- Carrega refs Oracle (lookup de regras) ----------
    ctx = _load_refs_oracle(spark, settings)

    # ---------- Aplica regras ----------
    # ITENS (CFOP/NCM) — as funções usam nomes padrões; mapeie se necessário antes.
    df_items_rules, m_it = apply_rules_to_items(
        df_items_base,
        ctx,
        apply_cfop_items=None,
        filter_cfop_items=None,
        apply_ncm=None,
        filter_ncm=None,
    )
    metrics.update({f"itens_{k}": v for k, v in (m_it or {}).items()})

    # DOCUMENTOS (GEN/CCE) — EFD não tem CCE como eventos de NFe, mas mantemos
    # a chamada com filtros neutros para aplicar GEN/Params (mapeamento de municípios, etc.).
    df_docs_rules, m_doc = apply_rules_to_documents(
        df_docs_base,
        ctx,
        apply_gen=None,
        apply_cce=False,           # por padrão, desabilita CCE p/ EFD
        filter_cce_excluded=None,
    )
    metrics.update({f"docs_{k}": v for k, v in (m_doc or {}).items()})

    # ---------- Agrega itens → documento ----------
    df_docs_aggr = _aggregate_items_to_document(df_docs_rules, df_items_rules, key_col=key_col)

    # ---------- Projeções finais ----------
    df_docs_final = _project_document_efd(df_docs_aggr, key_col=key_col)
    df_items_final = _project_item_efd(df_items_rules, key_col=key_col)

    metrics["docs_finais"]  = _safe_count(df_docs_final, "docs_final")
    metrics["itens_finais"] = _safe_count(df_items_final, "itens_final")

    # ---------- Escrita Iceberg ----------
    if write_iceberg:
        # Resolve tabelas de saída:
        if not out_doc_table:
            out_doc_table = settings.iceberg.document_table()  # padrão do seu projeto (IPM_DOCUMENTO_PARTCT_CALC_IPM)
        if not out_item_table:
            out_item_table = settings.iceberg.item_table()      # padrão do seu projeto (IPM_ITEM_DOCUMENTO)

        # DOCUMENTOS
        write_df(
            df_docs_final,
            settings=settings,
            format="iceberg",
            table=out_doc_table,
            mode=mode,
            key_columns=[ "codg_chave_acesso_nfe" ],  # merge por chave sintética EFD
        )
        bump_counts(spark, audit_id, "docs_escritos", metrics["docs_finais"], enabled=audit_enabled)

        # ITENS
        if df_items_final is not None:
            write_df(
                df_items_final,
                settings=settings,
                format="iceberg",
                table=out_item_table,
                mode=mode,
                key_columns=[ "codg_chave_acesso_nfe", "numr_item" ],
            )
            bump_counts(spark, audit_id, "itens_escritos", metrics["itens_finais"], enabled=audit_enabled)

    finish_success(spark, audit_id, extra=json.dumps(metrics), enabled=audit_enabled)
    return metrics

# =============================================================================
# CLI
# =============================================================================

def _build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Pipeline EFD (Kudu -> Regras -> Iceberg).")

    # Período
    p.add_argument("--data-inicio", required=True, help="Data inicial (YYYY-MM-DD)")
    p.add_argument("--data-fim", required=True, help="Data final (YYYY-MM-DD)")

    # Kudu
    p.add_argument("--kudu-db", default=_DEFAULT_KUDU_DB, help="Database/schema do Kudu (default: kudu)")
    p.add_argument("--efd-c100-table", default=_DEFAULT_TB_C100, help="Tabela C100 (documentos)")
    p.add_argument("--efd-c170-table", default=_DEFAULT_TB_C170, help="Tabela C170 (itens)")
    p.add_argument("--efd-e100-table", default=_DEFAULT_TB_E100, help="Tabela E100 (período de apuração) [opcional]")
    p.add_argument("--efd-e110-table", default=_DEFAULT_TB_E110, help="Tabela E110 (apuração/ajustes) [opcional]")

    # Colunas de pushdown e chave
    p.add_argument("--ts-doc-col", default=_DEFAULT_TS_DOC, help="Coluna TS (epoch) para C100 (default: dt_doc_nums)")
    p.add_argument("--ts-item-col", default=_DEFAULT_TS_ITEM, help="Coluna TS (epoch) para C170 (default: dt_doc_nums)")
    p.add_argument("--key-col", default=_DEFAULT_KEY_COL, help="Nome da coluna de chave do documento (default: doc_id)")

    # Saída
    p.add_argument("--out-doc-table", default=_DEFAULT_OUT_DOC, help="Tabela Iceberg de documentos (default: settings.iceberg.document_table())")
    p.add_argument("--out-item-table", default=_DEFAULT_OUT_ITEM, help="Tabela Iceberg de itens (default: settings.iceberg.item_table())")
    p.add_argument("--mode", default="merge", choices=["merge", "append"], help="Modo de escrita no Iceberg")

    # Execução
    p.add_argument("--no-audit", action="store_true", help="Desabilita auditoria")
    p.add_argument("--print-settings", action="store_true", help="Imprime Settings carregadas")
    p.add_argument("--no-write", action="store_true", help="Não escreve no Iceberg (apenas lê/processa)")

    return p

def main() -> None:
    args = _build_arg_parser().parse_args()

    settings: Settings = load_settings_from_env()
    spark: SparkSession = build_spark(settings, app_name="PROCESSO_CARGA_EFD_IPM")

    try:
        metrics = run_efd(
            spark,
            settings,
            data_inicio=args.data_inicio,
            data_fim=args.data_fim,
            kudu_db=args.kudu_db,
            efd_c100_table=args.efd_c100_table,
            efd_c170_table=args.efd_c170_table,
            efd_e100_table=args.efd_e100_table,
            efd_e110_table=args.efd_e110_table,
            ts_doc_col=args.ts_doc_col,
            ts_item_col=args.ts_item_col,
            key_col=args.key_col,
            out_doc_table=(args.out_doc_table or None),
            out_item_table=(args.out_item_table or None),
            mode=args.mode,
            print_settings_flag=bool(args.print_settings),
            audit_enabled=(not args.no_audit),
            write_iceberg=(not args.no_write),
        )
        print("[EFD] Métricas:", json.dumps(metrics, ensure_ascii=False))
    except Exception as e:
        finish_error(spark, start_and_get_id(spark, "EFD", enabled=True), str(e), enabled=True)
        raise
    finally:
        spark.stop()

if __name__ == "__main__":
    main()
