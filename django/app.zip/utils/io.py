# -*- coding: utf-8 -*-
# app/utils/io.py
"""
I/O utilitários do projeto:
- Leitura Kudu (NFe de alto volume)
- Leitura Oracle (auxiliares IPM), com pushdown e paralelismo
- Leitura/Escrita Iceberg nativa
- Escrita Parquet (fallback ou export)
- Retries com backoff para operações sensíveis (ex.: JDBC)

Observações:
- Os JARs correspondentes (Oracle JDBC, Iceberg runtime, Kudu) devem ser
  passados no spark-submit (--jars/--packages) conforme o ambiente.
- Este módulo não usa pandas e é seguro para execução em cluster (YARN).
"""

from __future__ import annotations

import os
import time
from typing import Iterable, List, Optional, Dict, Tuple, Union

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F

from app.settings import Settings


# =============================================================================
# Helpers
# =============================================================================
def _qualify_iceberg(settings: Settings, table: str, namespace: Optional[str] = None) -> str:
    """
    Monta o nome totalmente qualificado de uma tabela Iceberg.
    Ex.: tdp_catalog.ipm.ipm_documento_partct_calc_ipm
    """
    ns = namespace or settings.iceberg.namespace
    return f"{settings.iceberg.catalog}.{ns}.{table}"


def _full_kudu_name(settings: Settings, table_name: str, database: Optional[str] = None) -> str:
    """
    Constrói o identificador totalmente qualificado esperado pelo conector:
    impala::<db>.<table>
    """
    db = database or settings.kudu.database
    return f"impala::{db}.{table_name}"


def _list_from_csv(csv: Optional[str]) -> List[str]:
    if not csv:
        return []
    return [x.strip() for x in csv.split(",") if x.strip()]


def _sleep_backoff(attempt: int, base: float = 1.0, cap: float = 30.0) -> None:
    """Espera exponencial com jitter leve, evitando tempestade de retries."""
    delay = min(cap, base * (2 ** attempt)) * (1.0 + 0.1 * attempt)
    time.sleep(delay)


def with_retries(fn, max_attempts: int = 3, base_sleep: float = 1.0, what: str = "operation"):
    """
    Executa função com retries exponenciais. Re-lança a última exceção se falhar.
    """
    last_err = None
    for attempt in range(max_attempts):
        try:
            return fn()
        except Exception as e:
            last_err = e
            if attempt < max_attempts - 1:
                print(
                    f"[io.with_retries] {what} falhou (tentativa {attempt+1}/{max_attempts}). "
                    f"Tentando novamente... Erro: {e}"
                )
                _sleep_backoff(attempt, base_sleep)
            else:
                print(
                    f"[io.with_retries] {what} falhou definitivamente após {max_attempts} tentativas. Erro: {e}"
                )
    # só chega aqui se todas as tentativas falharem
    raise last_err  # type: ignore[misc]


# =============================================================================
# Leitura: Kudu
# =============================================================================
def read_kudu_table(
    spark: SparkSession,
    settings: Settings,
    *,
    table: str,
    database: Optional[str] = None,
    columns: Optional[List[str]] = None,
    where: Optional[Union[str, List[Tuple[str, str, object]]]] = None,
    leader_only: bool = True,
    read_latest: bool = True,
    fault_tolerant_scan: bool = False,
    op_timeout_ms: int = 180000,
    socket_timeout_ms: int = 180000,
    scan_request_timeout_ms: int = 600000,
    keepalive_ms: int = 15000,
) -> DataFrame:
    """
    Lê uma tabela Kudu com opções mais resilientes.
    - leader_only=True: evita followers atrasados
    - read_latest=True: evita 'READ_AT_SNAPSHOT'
    - timeouts maiores para ambientes sob carga

    Parâmetro 'where':
    - pode ser uma string SQL (ex.: "ide_dhemi_nums >= 1700 AND ide_dhemi_nums < 1800")
    - ou uma lista de tuplas simples: [("col", ">=", valor), ("col", "<", valor2)]
    """
    kudu_table = _full_kudu_name(settings, table, database)

    # Permite alternar apelido/qualificado do conector conforme ambiente.
    # Se settings.kudu.format não estiver setado, tenta variável de ambiente KUDU_FORMAT,
    # caindo por fim para 'kudu' (alias comum) — compatível com nfe.py.
    kudu_fmt = (
        getattr(getattr(settings, "kudu", object()), "format", None)
        or os.getenv("KUDU_FORMAT")
        or "kudu"
    )

    opts = {
        "kudu.master": settings.kudu.masters,
        "kudu.table": kudu_table,
        "kudu.operationTimeoutMs": str(op_timeout_ms),
        "kudu.socketReadTimeoutMs": str(socket_timeout_ms),
        # extras alinhados ao nfe.py
        "kudu.scanRequestTimeoutMs": str(scan_request_timeout_ms),
        "kudu.keepAlivePeriodMs": str(keepalive_ms),
    }
    if leader_only:
        opts["kudu.scanLocality"] = "leader_only"
    if read_latest:
        opts["kudu.readMode"] = "READ_LATEST"
    if fault_tolerant_scan:
        opts["kudu.faultTolerantScan"] = "true"

    df = spark.read.format(kudu_fmt).options(**opts).load()

    if where:
        if isinstance(where, str):
            df = df.filter(where)
        else:
            # lista de tuplas (col, op, val)
            for (c, op, v) in where:
                if op == "=":
                    df = df.filter(F.col(c) == v)
                elif op == "!=":
                    df = df.filter(F.col(c) != v)
                elif op == ">":
                    df = df.filter(F.col(c) > v)
                elif op == ">=":
                    df = df.filter(F.col(c) >= v)
                elif op == "<":
                    df = df.filter(F.col(c) < v)
                elif op == "<=":
                    df = df.filter(F.col(c) <= v)
                elif op.lower() == "between" and isinstance(v, (list, tuple)) and len(v) == 2:
                    df = df.filter((F.col(c) >= v[0]) & (F.col(c) <= v[1]))

    if columns:
        df = df.select(*columns)

    return df


# =============================================================================
# Leitura: Oracle JDBC
# =============================================================================
def _jdbc_url_from_dsn(dsn: str) -> str:
    """
    DSN aceitos:
    - "(DESCRIPTION=...)" -> jdbc:oracle:thin:@(DESCRIPTION=...)
    - "host:port/service" -> jdbc:oracle:thin:@//host:port/service (SERVICE_NAME)
    - "host:port:sid" -> jdbc:oracle:thin:@host:port:sid (SID)
    - já 'jdbc:oracle:thin:@...' -> retorna como está
    """
    if not dsn or not str(dsn).strip():
        raise ValueError("Oracle DSN vazio.")
    dsn = dsn.strip()
    if dsn.lower().startswith("jdbc:oracle:"):
        return dsn
    if dsn.startswith("("):  # TNS completo
        return f"jdbc:oracle:thin:@{dsn}"
    if "/" in dsn and ":" in dsn:  # EZCONNECT service name
        return f"jdbc:oracle:thin:@//{dsn}"
    return f"jdbc:oracle:thin:@{dsn}"  # SID


def _jdbc_options(settings: Settings) -> Dict[str, str]:
    """
    Opções JDBC comuns para Oracle. Ajuste conforme tuning do ambiente.
    Usa o DSN já normalizado em app/settings.py (começando com 'jdbc:oracle:thin:@').
    """
    dsn = _jdbc_url_from_dsn(settings.oracle.dsn)
    user = os.getenv("ORA_USER", settings.oracle.user)
    password = os.getenv("ORA_PASS", settings.oracle.password)
    return {
        "url": dsn,
        "user": user,
        "password": password,
        "driver": "oracle.jdbc.OracleDriver",
        "fetchsize": str(settings.oracle.fetchsize),
        # timeouts (atuam conforme versão do driver)
        "oracle.net.CONNECT_TIMEOUT": "15000",
        "oracle.jdbc.ReadTimeout": "120000",
        "oracle.net.TCP_KEEPALIVE": "true",
    }


def read_oracle_query(
    spark: SparkSession,
    settings: Settings,
    query_sql: str,
    *,
    columns: Optional[List[str]] = None,
    retries: int = 3,
) -> DataFrame:
    """Lê uma QUERY Oracle via JDBC, encapsulando como subselect."""
    opts = _jdbc_options(settings)
    sub = f"({query_sql}) QRY"

    def _do_read():
        reader = (
            spark.read
            .format("jdbc")
            .option("url", opts["url"])
            .option("user", opts["user"])
            .option("password", opts["password"])
            .option("driver", opts["driver"])
            .option("dbtable", sub)
            .option("fetchsize", opts["fetchsize"])
            .option("oracle.net.CONNECT_TIMEOUT", opts["oracle.net.CONNECT_TIMEOUT"])
            .option("oracle.jdbc.ReadTimeout", opts["oracle.jdbc.ReadTimeout"])
            .option("oracle.net.TCP_KEEPALIVE", opts["oracle.net.TCP_KEEPALIVE"])
            .option("pushDownPredicate", "true")
        )
        df0 = reader.load()
        if columns:
            return df0.select([F.col(c) for c in columns])
        return df0

    return with_retries(_do_read, max_attempts=retries, what="read_oracle_query")


def _read_oracle_with_opts(
    spark: SparkSession,
    *,
    user: str,
    password: str,
    dsn_chain: List[str],
    fetchsize: int,
    table: str,
    columns: Optional[List[str]] = None,
    where: Optional[str] = None,
    partition_column: Optional[str] = None,
    lower_bound: Optional[int] = None,
    upper_bound: Optional[int] = None,
    num_partitions: Optional[int] = None,
) -> DataFrame:
    """Tenta ler usando uma cadeia de DSNs (útil para failover/scan). Faz fallback em ORA-12514."""
    last_exc = None
    for dsn in dsn_chain:
        try:
            url = _jdbc_url_from_dsn(dsn)
            reader = (
                spark.read.format("jdbc")
                .option("url", url)
                .option("user", os.getenv("ORA_USER", user))
                .option("password", os.getenv("ORA_PASS", password))
                .option("driver", "oracle.jdbc.OracleDriver")
                .option("fetchsize", str(fetchsize))
                .option("oracle.net.CONNECT_TIMEOUT", "15000")
                .option("oracle.jdbc.ReadTimeout", "120000")
                .option("oracle.net.TCP_KEEPALIVE", "true")
            )

            if where:
                reader = (
                    reader.option("dbtable", f"(SELECT * FROM {table} WHERE {where}) T")
                    .option("pushDownPredicate", "true")
                )
            else:
                reader = reader.option("dbtable", table)

            if partition_column and (lower_bound is not None) and (upper_bound is not None) and (num_partitions or 0) > 0:
                reader = (
                    reader
                    .option("partitionColumn", partition_column)
                    .option("lowerBound", str(lower_bound))
                    .option("upperBound", str(upper_bound))
                    .option("numPartitions", str(num_partitions))
                )

            df = reader.load()
            if columns:
                keep = [c for c in columns if c in df.columns]
                if keep:
                    df = df.select(*keep)
            return df

        except Exception as e:
            msg = str(e)
            if "ORA-12514" in msg or "listener does not currently know of service" in msg:
                print(f"[io] DSN '{dsn}' rejeitado (ORA-12514). Tentando próximo DSN…")
                last_exc = e
                continue
            raise

    if last_exc:
        raise last_exc
    raise RuntimeError("Falha Oracle: nenhum DSN disponível.")


def read_oracle_table(*args, **kwargs) -> DataFrame:
    """
    Estilo A (recomendado):
        read_oracle_table(spark, settings, table, *, columns=None, where=None, ...)
    Estilo B (explícito):
        read_oracle_table(spark, table, *, user=..., password=..., dsn_primary=..., ...)
    Usa ENV ORA_DNS / ORA_DNS_FALLBACKS / ORA_USER / ORA_PASS como overrides quando definidos.
    """
    if len(args) < 2:
        raise TypeError(
            "uso: read_oracle_table(spark, settings, table, ...) ou read_oracle_table(spark, table, user=..., ...)"
        )

    spark = args[0]
    second = args[1]

    # -------------------------
    # Estilo B: (spark, "SCHEMA.TAB", user=..., password=..., dsn_primary=..., ...)
    # -------------------------
    if isinstance(second, str):
        table = second
        user = kwargs.pop("user")
        password = kwargs.pop("password")
        dsn_primary = kwargs.pop("dsn_primary")
        dsn_fallbacks = kwargs.pop("dsn_fallbacks", [])
        fetchsize = int(kwargs.pop("fetchsize", 10000))

        # overrides por ENV (se existirem)
        dsn_env = os.getenv("ORA_DNS")
        if dsn_env:
            dsn_primary = dsn_env
        env_fallbacks = [s.strip() for s in os.getenv("ORA_DNS_FALLBACKS", "").split(",") if s.strip()]

        dsn_chain = [dsn_primary] + list(dsn_fallbacks or []) + env_fallbacks

        return _read_oracle_with_opts(
            spark,
            user=user,
            password=password,
            dsn_chain=dsn_chain,
            fetchsize=fetchsize,
            table=table,
            columns=kwargs.pop("columns", None),
            where=kwargs.pop("where", None),
            partition_column=kwargs.pop("partition_column", None),
            lower_bound=kwargs.pop("lower_bound", None),
            upper_bound=kwargs.pop("upper_bound", None),
            num_partitions=kwargs.pop("num_partitions", None),
        )

    # -------------------------
    # Estilo A: (spark, settings, "SCHEMA.TAB", ...)
    # -------------------------
    settings = second
    if len(args) < 3 and "table" not in kwargs:
        raise TypeError("falta o parâmetro 'table' no estilo (spark, settings, table, ...)")

    table = args[2] if len(args) >= 3 else kwargs.pop("table")

    # pega bloco oracle do settings (preferir oracle_ipm)
    cfg = getattr(settings, "oracle_ipm", None) or getattr(settings, "oracle", None)
    if cfg is None:
        raise ValueError("Settings sem seção 'oracle' ou 'oracle_ipm'.")

    user = os.getenv("ORA_USER", getattr(cfg, "user"))
    password = os.getenv("ORA_PASS", getattr(cfg, "password"))
    fetchsize = int(getattr(cfg, "fetchsize", 10000))

    # DSNs: settings + ENV
    dsn_primary = os.getenv("ORA_DNS", getattr(cfg, "dsn", ""))
    dsn_fallbacks_cfg = list(getattr(cfg, "dsn_fallbacks", []))
    env_fallbacks = [s.strip() for s in os.getenv("ORA_DNS_FALLBACKS", "").split(",") if s.strip()]
    dsn_chain = [dsn_primary] + dsn_fallbacks_cfg + env_fallbacks

    return _read_oracle_with_opts(
        spark,
        user=user,
        password=password,
        dsn_chain=dsn_chain,
        fetchsize=fetchsize,
        table=table,
        columns=kwargs.pop("columns", None),
        where=kwargs.pop("where", None),
        partition_column=kwargs.pop("partition_column", None),
        lower_bound=kwargs.pop("lower_bound", None),
        upper_bound=kwargs.pop("upper_bound", None),
        num_partitions=kwargs.pop("num_partitions", None),
    )


# =============================================================================
# Leitura: Iceberg
# =============================================================================
def read_iceberg_table(
    spark: SparkSession,
    settings: Settings,
    table: str,
    *,
    namespace: Optional[str] = None,
    columns: Optional[List[str]] = None,
    where: Optional[str] = None,
) -> DataFrame:
    """Lê uma tabela Iceberg nativamente."""
    full = _qualify_iceberg(settings, table, namespace)
    df = spark.read.table(full)
    if columns:
        df = df.select([F.col(c) for c in columns])
    if where:
        df = df.filter(where)
    return df


# =============================================================================
# Escrita: Iceberg e Parquet
# =============================================================================
def write_iceberg(
    df: DataFrame,
    settings: Settings,
    table: str,
    *,
    namespace: Optional[str] = None,
    mode: str = "append",
    partition_by: Optional[str] = None,
) -> None:
    """
    Escreve DataFrame em Iceberg como tabela (create/append/overwrite).
    Usa saveAsTable, permitindo criação automática se não existir.
    """
    full_name = _qualify_iceberg(settings, table, namespace)
    writer = df.write.mode(mode).format("iceberg")
    if partition_by:
        parts = _list_from_csv(partition_by)
        if parts:
            writer = writer.partitionBy(*parts)
    writer.saveAsTable(full_name)


def write_parquet(
    df: DataFrame,
    output: str,
    *,
    mode: str = "append",
    partition_by: Optional[str] = None,
) -> None:
    """Escreve DataFrame em Parquet (ex.: export ou debug de amostras)."""
    writer = df.write.mode(mode).format("parquet")
    if partition_by:
        parts = _list_from_csv(partition_by)
        if parts:
            writer = writer.partitionBy(*parts)
    writer.save(output)


def write_df(
    df: DataFrame,
    *,
    settings: Optional[Settings] = None,
    output_format: str = "iceberg",
    table_name: Optional[str] = None,
    output: Optional[str] = None,
    mode: str = "append",
    partition_by: Optional[str] = None,
    namespace: Optional[str] = None,
) -> None:
    """
    Wrapper único para escrita:
    - output_format="iceberg": exige settings e table_name
    - output_format="parquet": exige output (path)
    """
    fmt = (output_format or "").lower()
    if fmt == "iceberg":
        if not settings or not table_name:
            raise ValueError("Para escrever em Iceberg, informe settings e table_name.")
        return write_iceberg(
            df,
            settings,
            table_name,
            namespace=namespace,
            mode=mode,
            partition_by=partition_by,
        )
    elif fmt == "parquet":
        if not output:
            raise ValueError("Para escrever em Parquet, informe --output com o caminho de destino.")
        return write_parquet(df, output, mode=mode, partition_by=partition_by)
    else:
        raise ValueError(f"Formato de saída não suportado: {output_format}")


# =============================================================================
# Conveniências específicas do projeto (Kudu)
# =============================================================================
def read_kudu_nfe_ident(
    spark: SparkSession,
    settings: Settings,
    *,
    columns: Optional[List[str]] = None,
    where: Optional[Union[str, List[Tuple[str, str, object]]]] = None,
) -> DataFrame:
    """Leitura padrão da base de identificação NFe no Kudu."""
    return read_kudu_table(
        spark=spark,
        settings=settings,
        table=settings.kudu.nfe_ident_table,
        database=settings.kudu.database,
        columns=columns,
        where=where,
    )


def read_kudu_nfe_itens(
    spark: SparkSession,
    settings: Settings,
    *,
    columns: Optional[List[str]] = None,
    where: Optional[Union[str, List[Tuple[str, str, object]]]] = None,
) -> DataFrame:
    """Leitura padrão da base de itens NFe no Kudu."""
    return read_kudu_table(
        spark=spark,
        settings=settings,
        table=settings.kudu.nfe_item_table,
        database=settings.kudu.database,
        columns=columns,
        where=where,
    )


# =============================================================================
# Conveniências específicas do projeto (Oracle / IPM)
# =============================================================================
def _safe_read_oracle_table(
    spark: SparkSession,
    settings: Settings,
    table_name: Optional[str],
    *,
    required: bool = False,
    what: Optional[str] = None,
    **reader_kwargs,
) -> Optional[DataFrame]:
    """
    Leitura tolerante: retorna None se a tabela não existir ou se table_name for vazio/None.
    Se required=True, relança a exceção.
    """
    if not table_name:
        return None

    label = what or f"read_oracle_table({table_name})"
    try:
        return read_oracle_table(spark, settings, table_name, **reader_kwargs)
    except Exception as e:
        if required:
            print(f"[io.oracle] ERRO ao ler {table_name} (obrigatória).")
            raise
        print(f"[io.oracle] Aviso: não foi possível ler {table_name}. Pulando. Erro: {e}")
        return None


def read_oracle_ipm_auxiliares(
    spark: SparkSession,
    settings: Settings,
) -> Dict[str, Optional[DataFrame]]:
    """
    Lê as tabelas auxiliares necessárias às regras de negócio (Oracle IPM).
    Retorna dicionário com DFs. Parâmetros são obrigatórios; demais são opcionais.
    Também devolve chaves compatíveis com versões antigas do projeto.
    """
    # Preferir bloco oracle_ipm quando existir
    o = getattr(settings, "oracle_ipm", None) or settings.oracle

    params_df = _safe_read_oracle_table(
        spark, settings, getattr(o, "tbl_parametros", None), required=True, what="parametros"
    )
    cfop_df = _safe_read_oracle_table(
        spark, settings, getattr(o, "tbl_cfop_participante", None), what="cfop_participante"
    )
    evento_df = _safe_read_oracle_table(
        spark, settings, getattr(o, "tbl_evento", None), what="evento"
    )
    ncm_df = _safe_read_oracle_table(
        spark, settings, getattr(o, "tbl_ncm_participante", None), what="ncm_participante"
    )
    mun_df = _safe_read_oracle_table(
        spark, settings, getattr(o, "tbl_municipios", None), what="municipios"
    )
    doc_ref = _safe_read_oracle_table(
        spark, settings, getattr(o, "tbl_documento", None), what="documento_ref"
    )

    # Mapa "novo" (usado nas regras que sugeri)
    out: Dict[str, Optional[DataFrame]] = {
        "params": params_df,
        "cfop": cfop_df,
        "evento": evento_df,
        "ncm": ncm_df,
        "mun": mun_df,
        "doc_ref": doc_ref,
    }

    # Compatibilidade com o naming antigo (se alguma parte do projeto ainda esperar):
    out["parametros"] = params_df
    out["cfop_participante"] = cfop_df
    out["ncm_participante"] = ncm_df
    out["municipios"] = mun_df
    out["documento"] = doc_ref

    return out
