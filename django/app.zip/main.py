# -*- coding: utf-8 -*-
# app/main.py
"""
CLI orchestration for the pipelines (Django -> Spark)

Implements:
  - NFE (Kudu -> Rules -> Iceberg)

Examples:
  spark-submit ... app/main.py \
    --document nfe \
    --data-inicio 2024-01-01 --data-fim 2024-01-31 \
    --dt-inicio "2024-01-01 00:00:00" --dt-fim "2024-01-31 23:59:59" \
    --prefer-day-partition true \
    --truncate-iceberg --no-audit --print-settings true
"""

from __future__ import annotations

import argparse
import os
import sys
from typing import Dict, Optional
from datetime import datetime, timedelta

from pyspark.sql import SparkSession

from app.settings import (
    Settings,
    load_settings_from_env,
    build_spark,
    print_settings,
)
from app.nfe import run_nfe


# -----------------------------------------------------------------------------
# helpers
# -----------------------------------------------------------------------------
def _parse_bool(v: str) -> bool:
    return str(v).strip().lower() in {"1", "true", "t", "y", "yes", "sim", "s"}

def _mk_where_ts_auto(dt_inicio: Optional[str], dt_fim: Optional[str], *, col: str = "ide_dhemi_nums") -> Optional[str]:
    """
    Where que funciona se a coluna for:
      - epoch (segundos)  OU
      - yyyyMMddHHmmss (14 dígitos)
    """
    if not dt_inicio or not dt_fim:
        return None
    di = dt_inicio.replace("T", " ")
    df = dt_fim.replace("T", " ")

    di_num = f"{di[:10]} {di[11:19]}".replace("-", "").replace(" ", "").replace(":", "")
    df_num = f"{df[:10]} {df[11:19]}".replace("-", "").replace(" ", "").replace(":", "")

    where_sql = f"""
        (
          (length(cast({col} as string)) <= 10 AND
             {col} BETWEEN unix_timestamp('{di}') AND unix_timestamp('{df}')
          )
          OR
          (length(cast({col} as string)) >= 12 AND
             {col} BETWEEN CAST('{di_num}' as BIGINT) AND CAST('{df_num}' as BIGINT)
          )
        )
    """
    # normaliza espaços
    return " ".join(where_sql.split())


# -----------------------------------------------------------------------------
# parser
# -----------------------------------------------------------------------------
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Executor de pipelines (Projeto Django -> Spark)")
    p.add_argument("--document", default="nfe", choices=["nfe"], help="Documento alvo")
    p.add_argument("--data-inicio", required=True, help="Data inicial AAAA-MM-DD (auditoria / janela)")
    p.add_argument("--data-fim", required=True, help="Data final AAAA-MM-DD (auditoria / janela)")
    p.add_argument("--where-docs", default=None, help="Filtro SQL para leitura de documentos (fonte)")
    p.add_argument("--where-itens", default=None, help="Filtro SQL para leitura de itens (fonte)")
    p.add_argument("--dt-inicio", default=None, help="AAAA-MM-DD HH:MM:SS (gera WHERE por ide_dhemi_nums)")
    p.add_argument("--dt-fim", default=None, help="AAAA-MM-DD HH:MM:SS (gera WHERE por ide_dhemi_nums)")
    p.add_argument("--prefer-day-partition", default="false", help="true/false: executar dia a dia")
    p.add_argument("--print-settings", default="false", help="true/false: imprime settings")
    p.add_argument("--no-audit", action="store_true", help="Quando presente, desativa auditoria")
    p.add_argument("--truncate-iceberg", action="store_true", help="TRUNCATE nas tabelas Iceberg antes de gravar")
    p.add_argument("--delete-iceberg-window", action="store_true",
                   help="DELETE somente a janela [data-inicio, data-fim] antes de gravar")

    # Evita precisar exportar variáveis de ambiente
    p.add_argument("--kudu-masters", default=None,
                   help="Lista de masters do Kudu (se vazio, usa default interno)")
    p.add_argument("--kudu-db", default=None,
                   help="Database do Kudu (se vazio, usa default interno)")
    return p


# -----------------------------------------------------------------------------
# demux documento
# -----------------------------------------------------------------------------
def run_document_pipeline(
    document: str,
    spark: SparkSession,
    settings: Settings,
    *,
    data_inicio: str,
    data_fim: str,
    where_docs: Optional[str],
    where_itens: Optional[str],
    prefer_day_partition: bool,
    audit_enabled: bool
) -> Dict[str, int]:
    doc = (document or "").strip().lower()
    if doc == "nfe":
        return run_nfe(
            spark, settings,
            data_inicio=data_inicio,
            data_fim=data_fim,
            where_docs=where_docs,
            where_itens=where_itens,
            prefer_day_partition=prefer_day_partition,
            audit_params={"cli": True, "document": "NFE"},
            audit_enabled=audit_enabled,
        )
    raise ValueError(f"Documento não suportado: {document}. Use 'nfe'.")


# -----------------------------------------------------------------------------
# main
# -----------------------------------------------------------------------------
def main(argv=None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)

    # Defaults para não precisar exportar antes do submit
    if args.kudu_masters:
        os.environ["KUDU_MASTERS"] = args.kudu_masters
    else:
        os.environ.setdefault(
            "KUDU_MASTERS",
            "bdades01-node01.sefaz.go.gov.br:7051,bdades01-node02.sefaz.go.gov.br:7051,bdades01-node03.sefaz.go.gov.br:7051",
        )
    if args.kudu_db:
        os.environ["KUDU_DB"] = args.kudu_db
    else:
        os.environ.setdefault("KUDU_DB", "nfe")

    settings = load_settings_from_env()
    spark = build_spark(settings)

    try:
        if _parse_bool(args.print_settings):
            print_settings(settings)

        prefer_day = _parse_bool(args.prefer_day_partition)

        # WHERE padrão gerado por ide_dhemi_nums (epoch ou yyyymmddHHMMSS)
        # Obs.: o nfe.py usa data-inicio/data-fim para montar o filtro no Kudu,
        # mas mantemos where_docs/itens para compatibilidade/análise.
        where_ts = _mk_where_ts_auto(args.dt_inicio, args.dt_fim, col="ide_dhemi_nums")
        base_where_docs = args.where_docs or where_ts
        base_where_itens = args.where_itens or where_ts

        # Operações pré-escrita (truncate / delete janela) — executadas uma única vez
        fq_doc  = f"{settings.iceberg.namespace}.{settings.iceberg.tbl_documento_partct}"
        fq_item = f"{settings.iceberg.namespace}.{settings.iceberg.tbl_item_documento}"

        if args.truncate_iceberg:
            print(f"[main] TRUNCATE TABLE {fq_doc}")
            spark.sql(f"TRUNCATE TABLE {fq_doc}")
            print(f"[main] TRUNCATE TABLE {fq_item}")
            spark.sql(f"TRUNCATE TABLE {fq_item}")

        if args.delete_iceberg_window:
            di = args.data_inicio  # 'YYYY-MM-DD'
            df = args.data_fim     # 'YYYY-MM-DD' (fim inclusivo -> usamos < +1 dia)
            print(f"[main] DELETE janela em {fq_doc} e {fq_item}: [{di}, {df}]")
            spark.sql(f"""
                DELETE FROM {fq_doc}
                WHERE DATA_EMISSAO_NFE >= DATE '{di}'
                  AND DATA_EMISSAO_NFE <  DATE '{df}' + INTERVAL 1 DAY
            """)
            spark.sql(f"""
                DELETE FROM {fq_item}
                WHERE CODG_CHAVE_ACESSO_NFE IN (
                    SELECT CODG_CHAVE_ACESSO_NFE
                    FROM {fq_doc}
                    WHERE DATA_EMISSAO_NFE >= DATE '{di}'
                      AND DATA_EMISSAO_NFE <  DATE '{df}' + INTERVAL 1 DAY
                )
            """)

        # Execução em janela única (default) OU dia a dia (prefer_day = True)
        if not prefer_day:
            metrics = run_document_pipeline(
                args.document,
                spark,
                settings,
                data_inicio=args.data_inicio,
                data_fim=args.data_fim,
                where_docs=base_where_docs,
                where_itens=base_where_itens,
                prefer_day_partition=False,
                audit_enabled=(not args.no_audit),
            )

            print("=== Metrics ===")
            for k in sorted(metrics.keys()):
                print(f"{k}: {metrics[k]}")

        else:
            # Loop diário inclusivo
            di = datetime.strptime(args.data_inicio, "%Y-%m-%d").date()
            df = datetime.strptime(args.data_fim, "%Y-%m-%d").date()

            # acumulador simples para um sumário final
            acc: Dict[str, int] = {}

            cur = di
            while cur <= df:
                dia = cur.strftime("%Y-%m-%d")
                # where_ts diário (se for útil para debugging/log)
                day_where = _mk_where_ts_auto(f"{dia} 00:00:00", f"{dia} 23:59:59", col="ide_dhemi_nums")

                print(f"\n[main] >>> Executando dia {dia}")
                m = run_document_pipeline(
                    args.document,
                    spark,
                    settings,
                    data_inicio=dia,
                    data_fim=dia,
                    where_docs=day_where or base_where_docs,
                    where_itens=day_where or base_where_itens,
                    prefer_day_partition=True,
                    audit_enabled=(not args.no_audit),
                )

                # imprime métricas do dia
                print(f"=== Metrics {dia} ===")
                for k in sorted(m.keys()):
                    print(f"{k}: {m[k]}")
                    # acumula apenas chaves numéricas
                    try:
                        acc[k] = acc.get(k, 0) + int(m[k])
                    except Exception:
                        # ignora não numéricos
                        pass

                cur += timedelta(days=1)

            # sumário acumulado
            if acc:
                print("\n=== Metrics (SUMÁRIO do período) ===")
                for k in sorted(acc.keys()):
                    print(f"{k}: {acc[k]}")

    except Exception as e:
        print(f"[main] Error: {e}", file=sys.stderr)
        raise
    finally:
        spark.stop()


if __name__ == "__main__":
    main()
