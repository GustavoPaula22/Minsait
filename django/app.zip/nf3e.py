# -*- coding: utf-8 -*-
# app/nf3e.py
from __future__ import annotations

import argparse
import json
import os
from typing import Dict, Optional, Tuple, List

from pyspark.sql import DataFrame, SparkSession, Window
from pyspark.sql import functions as F
from pyspark.sql import types as T

from app.settings import Settings, load_settings_from_env, build_spark, print_settings
from app.utils.io import write_df, read_oracle_table, read_kudu_table
from app.utils.audit import start_and_get_id, bump_counts, finish_success, finish_error
from app.utils.rules import (
    RulesContext,
    load_params_ref,
    load_cfop_ref,
    load_ncm_ref,
    load_cce_ref,
    load_gen_ref,
    apply_rules_to_items,
    apply_rules_to_documents,
    ensure_business_columns,
    get_param,
)
from app.projections import project_document, project_item


# =============================================================================
# Defaults (ajuste os nomes se seu Kudu usar outro padrão)
# =============================================================================
# Observação: os nomes podem ser sobrescritos por CLI (--nf3e-*-table) ou ENV.
_DEFAULT_KUDU_DB = os.getenv("NF3E_KUDU_DB", "kudu")

# Tabelas típicas (ajuste conforme seu esquema real no Kudu)
_DEFAULT_TB_DOC = os.getenv("NF3E_DOC_TABLE",  "nf3e_b_identificacao_nf3e")                 # base do doc
_DEFAULT_TB_EMIT = os.getenv("NF3E_EMIT_TABLE", "nf3e_c_identificacao_emitente_nf3e")       # emitente
_DEFAULT_TB_DEST = os.getenv("NF3E_DEST_TABLE", "nf3e_e_identificacao_destinatario_nf3e")   # destinatário
_DEFAULT_TB_ITEN = os.getenv("NF3E_ITEM_TABLE", "nf3e_i_itens_nf3e")                        # itens (quando houver)
_DEFAULT_TB_TOT  = os.getenv("NF3E_TOT_TABLE",  "nf3e_w_total_nf3e")                        # totais (se existir)

# Coluna timestamp numérica (segundos epoch) usada para pushdown
_TS_COL = os.getenv("NF3E_TS_COL", "ide_dhemi_nums")

# Chave NF3e (ajuste se usar outro nome na sua base)
_KEY_COL = os.getenv("NF3E_KEY_COL", "chavenf3e")


# =============================================================================
# Helpers
# =============================================================================
def _normalize_table_name(n: str, *, db: Optional[str], for_format: str = "kudu") -> str:
    """Permite passar 'tb' ou 'db.tb'. Para o conector Kudu, retornamos em sintaxe impala::db.tb."""
    if "." not in n and db:
        n = f"{db}.{n}"
    if for_format.lower() in ("kudu", "impala"):
        return f"impala::{n}"
    return n


def _mk_kudu_between_where(
    data_inicio: str,
    data_fim: str,
    chave: Optional[str] = None,
    ts_col: str = _TS_COL,
    key_col: str = _KEY_COL,
) -> str:
    di = f"{data_inicio.strip()} 00:00:00"
    df = f"{data_fim.strip()} 23:59:59"
    base = f"{ts_col} BETWEEN unix_timestamp('{di}') AND unix_timestamp('{df}')"
    if chave:
        base += f" AND {key_col} = '{chave.strip()}'"
    return base


def _safe_count(df: DataFrame, *, what: str) -> int:
    try:
        return int(df.count())
    except Exception as e:
        print(f"[nf3e][_safe_count] Falha ao contar {what}: {e}")
        return -1


def _select_if(df: DataFrame, columns: Optional[List[str]]) -> DataFrame:
    if columns:
        keep = [c for c in columns if c in df.columns]
        if keep:
            return df.select(*keep)
    return df


# =============================================================================
# Leitura Kudu (NF3e)
# =============================================================================
def _read_nf3e_docs(
    spark: SparkSession,
    settings: Settings,
    *,
    kudu_db: str,
    tb_doc: str,
    tb_emit: Optional[str],
    tb_dest: Optional[str],
    tb_tot: Optional[str],
    where_sql: str,
) -> DataFrame:
    """Monta o DF de documentos NF3e unindo base + emitente/destinatário (+ totais quando existir)."""

    # base
    df_base = read_kudu_table(
        spark,
        settings,
        table=_normalize_table_name(tb_doc, db=kudu_db),
        where=where_sql,
        columns=None,
    )

    cur = df_base

    # emitente
    if tb_emit:
        df_emit = read_kudu_table(
            spark,
            settings,
            table=_normalize_table_name(tb_emit, db=kudu_db),
            where=where_sql,
            columns=None,
        )
        if _KEY_COL in df_emit.columns:
            df_emit = df_emit.select(_KEY_COL, *[c for c in df_emit.columns if c != _KEY_COL])
            cur = cur.join(df_emit, on=_KEY_COL, how="left")

    # destinatário
    if tb_dest:
        df_dest = read_kudu_table(
            spark,
            settings,
            table=_normalize_table_name(tb_dest, db=kudu_db),
            where=where_sql,
            columns=None,
        )
        if _KEY_COL in df_dest.columns:
            df_dest = df_dest.select(_KEY_COL, *[c for c in df_dest.columns if c != _KEY_COL])
            cur = cur.join(df_dest, on=_KEY_COL, how="left")

    # totais (se existir)
    if tb_tot:
        df_tot = read_kudu_table(
            spark,
            settings,
            table=_normalize_table_name(tb_tot, db=kudu_db),
            where=where_sql,
            columns=None,
        )
        if _KEY_COL in df_tot.columns:
            df_tot = df_tot.select(_KEY_COL, *[c for c in df_tot.columns if c != _KEY_COL])
            cur = cur.join(df_tot, on=_KEY_COL, how="left")

    return cur


def _read_nf3e_items(
    spark: SparkSession,
    settings: Settings,
    *,
    kudu_db: str,
    tb_item: Optional[str],
    where_sql: str,
) -> Optional[DataFrame]:
    """Lê itens NF3e (se houver tabela de itens no Kudu)."""
    if not tb_item:
        return None
    df_it = read_kudu_table(
        spark,
        settings,
        table=_normalize_table_name(tb_item, db=kudu_db),
        where=where_sql,
        columns=None,
    )
    return df_it


# =============================================================================
# Regras: carrega referências Oracle e aplica (sem ETL de auxiliares)
# =============================================================================
def _load_refs_oracle(spark: SparkSession, settings: Settings) -> RulesContext:
    """Carrega referências do Oracle para regras (Params, CFOP, CCE, NCM, GEN)."""
    df_params = load_params_ref(spark, settings)           # IPM_PARAMETROS_PROCESSAMENTO (normalizado)
    df_cfop   = load_cfop_ref(spark, settings)             # IPM_CFOP_PARTICIPANTE
    df_ncm    = load_ncm_ref(spark, settings)              # IPM_NCM_PARTICIPANTE / correlatos
    df_evt    = load_cce_ref(spark, settings)              # IPM_EVENTO (CCE, cancelamento, inutilização, substituição)
    df_gen    = load_gen_ref(spark, settings)              # IPM_MUNICIPIOS / mapeamentos

    return RulesContext(
        df_params=df_params,
        df_cfop_ref=df_cfop,
        df_ncm_ref=df_ncm,
        df_eventos=df_evt,
        df_gen=df_gen,
        params_dict=load_params_ref(spark, settings, as_dict=True),  # otimiza acesso a parâmetros
    )


# =============================================================================
# Agregações e projeções finais
# =============================================================================
def _aggregate_items_to_document(df_docs: DataFrame, df_items_rules: Optional[DataFrame]) -> DataFrame:
    """
    A partir dos ITENS já com regras (is_cfop_participante / ncm_participante / valr_adicionado),
    agrega indicadores para o DOCUMENTO: indi_aprop, valr_adicionado_operacao, codg_tipo_doc_partct.
    """
    if df_items_rules is None:
        # Sem itens: garante colunas obrigatórias com defaults neutros
        docs = df_docs.withColumn("indi_aprop", F.lit(None).cast("string")) \
                      .withColumn("valr_adicionado_operacao", F.lit(None).cast(T.DecimalType(17, 2))) \
                      .withColumn("codg_tipo_doc_partct", F.lit(None).cast("int"))
        return docs

    grp = (
        df_items_rules.groupBy(_KEY_COL)
        .agg(
            F.sum(F.coalesce(F.col("valr_adicionado").cast(T.DecimalType(17, 2)), F.lit(0))).alias(
                "valr_adicionado_operacao"
            ),
            F.max(F.when(F.col("is_cfop_participante") == F.lit(True), F.lit(1)).otherwise(F.lit(0))).alias(
                "has_part_item"
            ),
            F.max(F.coalesce(F.col("codg_tipo_doc_partct_item").cast("int"), F.lit(0))).alias(
                "codg_tipo_doc_partct"
            ),
        )
    )

    docs = (
        df_docs.join(grp, on=_KEY_COL, how="left")
        .withColumn(
            "indi_aprop",
            F.when(F.col("has_part_item") == F.lit(1), F.lit("S")).otherwise(F.lit("N")),
        )
        .drop("has_part_item")
    )
    return docs


# =============================================================================
# Pipeline NF3e
# =============================================================================
def run_nf3e(
    spark: SparkSession,
    settings: Settings,
    *,
    data_inicio: str,
    data_fim: str,
    chave: Optional[str] = None,
    kudu_db: str = _DEFAULT_KUDU_DB,
    nf3e_doc_table: str = _DEFAULT_TB_DOC,
    nf3e_emit_table: Optional[str] = _DEFAULT_TB_EMIT,
    nf3e_dest_table: Optional[str] = _DEFAULT_TB_DEST,
    nf3e_item_table: Optional[str] = _DEFAULT_TB_ITEN,
    nf3e_total_table: Optional[str] = _DEFAULT_TB_TOT,
    print_settings_flag: bool = False,
    audit_enabled: bool = True,
    write_iceberg: bool = True,
    mode: str = "merge",  # merge|append (merge é idempotente, recomendado)
) -> Dict[str, int]:
    """
    Executa o pipeline NF3e (Kudu -> Regras -> Iceberg).
    Retorna métricas simples para auditoria.
    """
    if print_settings_flag:
        print_settings(settings)

    audit_id = start_and_get_id(spark, "NF3E", enabled=audit_enabled)

    # ---------- Kudu pushdown ----------
    where_sql = _mk_kudu_between_where(data_inicio, data_fim, chave=chave, ts_col=_TS_COL, key_col=_KEY_COL)

    # ---------- Leitura DOCS / ITENS ----------
    df_docs_base = _read_nf3e_docs(
        spark,
        settings,
        kudu_db=kudu_db,
        tb_doc=nf3e_doc_table,
        tb_emit=nf3e_emit_table,
        tb_dest=nf3e_dest_table,
        tb_tot=nf3e_total_table,
        where_sql=where_sql,
    )
    df_items_base = _read_nf3e_items(
        spark,
        settings,
        kudu_db=kudu_db,
        tb_item=nf3e_item_table,
        where_sql=where_sql,
    )

    metrics: Dict[str, int] = {}
    metrics["docs_lidos"] = _safe_count(df_docs_base, what="docs_base")
    metrics["itens_lidos"] = _safe_count(df_items_base, what="itens_base") if df_items_base is not None else 0

    # ---------- Carrega refs Oracle (sem ETL) e aplica regras ----------
    ctx = _load_refs_oracle(spark, settings)

    # 1) ITENS -> aplica CFOP/NCM (e garante colunas mínimas)
    df_items_rules = None
    if df_items_base is not None:
        df_items_rules, m_it = apply_rules_to_items(
            df_items_base,
            ctx,
            apply_cfop_items=None,                  # usa parâmetro de processamento
            filter_cfop_items=None,                 # idem
            apply_ncm=None,
            filter_ncm=None,
        )
        metrics.update({f"itens_{k}": v for k, v in m_it.items()})

    # 2) DOCS -> aplica GEN/CCE e garante colunas mínimas
    df_docs_rules, m_doc = apply_rules_to_documents(
        df_docs_base,
        ctx,
        apply_gen=None,
        apply_cce=None,
        filter_cce_excluded=None,
    )
    metrics.update({f"docs_{k}": v for k, v in m_doc.items()})

    # 3) Agrega itens -> documento (indi_aprop / valr_adicionado_operacao / codg_tipo_doc_partct)
    df_docs_aggr = _aggregate_items_to_document(df_docs_rules, df_items_rules)

    # ---------- Projeções finais ----------
    df_docs_final = project_document(df_docs_aggr, key_col=_KEY_COL)
    df_items_final = project_item(df_items_rules, key_col=_KEY_COL) if df_items_rules is not None else None

    metrics["docs_finais"] = _safe_count(df_docs_final, what="docs_final")
    metrics["itens_finais"] = _safe_count(df_items_final, what="itens_final") if df_items_final is not None else 0

    # ---------- Escrita Iceberg ----------
    if write_iceberg:
        # Mesmas tabelas IPM já usadas pelo NFe/CTe/BPe
        doc_table = settings.iceberg.document_table()  # tdp_catalog.ipm.ipm_documento_partct_calc_ipm
        item_table = settings.iceberg.item_table()     # tdp_catalog.ipm.ipm_item_documento

        write_df(
            df_docs_final,
            settings=settings,
            format="iceberg",
            table=doc_table,
            mode=mode,
            key_columns=[_KEY_COL],  # merge idempotente por chave do documento
        )
        bump_counts(spark, audit_id, "docs_escritos", metrics["docs_finais"], enabled=audit_enabled)

        if df_items_final is not None:
            write_df(
                df_items_final,
                settings=settings,
                format="iceberg",
                table=item_table,
                mode=mode,
                key_columns=[_KEY_COL, "numr_item"],  # chave composta doc+item
            )
            bump_counts(spark, audit_id, "itens_escritos", metrics["itens_finais"], enabled=audit_enabled)

    finish_success(spark, audit_id, extra=json.dumps(metrics), enabled=audit_enabled)
    return metrics


# =============================================================================
# CLI
# =============================================================================
def _build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Pipeline NF3e (Kudu -> Regras -> Iceberg).")

    # Período/chave
    p.add_argument("--data-inicio", required=True, help="Data inicial (YYYY-MM-DD)")
    p.add_argument("--data-fim", required=True, help="Data final (YYYY-MM-DD)")
    p.add_argument("--chave", required=False, default=None, help="Filtrar por uma única chave NF3e")

    # Kudu
    p.add_argument("--kudu-db", default=_DEFAULT_KUDU_DB, help="Database/schema do Kudu (default: kudu)")
    p.add_argument("--nf3e-doc-table", default=_DEFAULT_TB_DOC, help="Tabela base de documentos NF3e")
    p.add_argument("--nf3e-emit-table", default=_DEFAULT_TB_EMIT, help="Tabela de emitente NF3e (opcional)")
    p.add_argument("--nf3e-dest-table", default=_DEFAULT_TB_DEST, help="Tabela de destinatário NF3e (opcional)")
    p.add_argument("--nf3e-item-table", default=_DEFAULT_TB_ITEN, help="Tabela de itens NF3e (opcional)")
    p.add_argument("--nf3e-total-table", default=_DEFAULT_TB_TOT, help="Tabela de totais NF3e (opcional)")

    # Execução
    p.add_argument("--no-audit", action="store_true", help="Desabilita auditoria")
    p.add_argument("--print-settings", action="store_true", help="Imprime Settings")
    p.add_argument("--no-write", action="store_true", help="Não escreve no Iceberg (apenas lê/processa)")
    p.add_argument("--mode", default="merge", choices=["merge", "append"], help="Modo de escrita no Iceberg")

    return p


def main() -> None:
    args = _build_arg_parser().parse_args()

    settings: Settings = load_settings_from_env()
    spark: SparkSession = build_spark(settings, app_name="PROCESSO_CARGA_NF3E_IPM")

    try:
        metrics = run_nf3e(
            spark,
            settings,
            data_inicio=args.data_inicio,
            data_fim=args.data_fim,
            chave=args.chave,
            kudu_db=args.kudu_db,
            nf3e_doc_table=args.nf3e_doc_table,
            nf3e_emit_table=args.nf3e_emit_table,
            nf3e_dest_table=args.nf3e_dest_table,
            nf3e_item_table=args.nf3e_item_table,
            nf3e_total_table=args.nf3e_total_table,
            print_settings_flag=bool(args.print_settings),
            audit_enabled=(not args.no_audit),
            write_iceberg=(not args.no_write),
            mode=args.mode,
        )
        print("[NF3e] Métricas:", json.dumps(metrics, ensure_ascii=False))
    except Exception as e:
        finish_error(spark, start_and_get_id(spark, "NF3E", enabled=True), str(e), enabled=True)
        raise
    finally:
        spark.stop()


if __name__ == "__main__":
    main()
