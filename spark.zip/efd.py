from __future__ import annotations

import argparse
import json
import os
from typing import Dict, List, Optional, Tuple

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql.window import Window

from app.settings import Settings, load_settings_from_env, build_spark, print_settings
from app.utils.audit import start_and_get_id, bump_counts, finish_success, finish_error
from app.utils.io import read_kudu_efd_c100, read_kudu_efd_c170, write_df
from app.utils.rules import (
    build_rules_context,
    apply_rules_to_items,
    RulesContext,
)

# =============================================================================
# Constantes EFD
# =============================================================================
TIPO_DOC_PARTCT_EFD = 7
TIPO_DOCUMENTO_FISCAL_EFD = "01"  # Nota Fiscal modelo 1/1A

# EFD não tem chave única como NFe/CTe, usa chave sintética
KEY_COL = "chave_sintetica_efd"


# =============================================================================
# Helpers
# =============================================================================
def _safe_count(df: DataFrame, *, kind: str = "count") -> int:
    """Count seguro com tratamento de erro Kudu"""
    try:
        return int(df.count())
    except Exception as e:
        msg = str(e)
        if ("Tablet is lagging too much" in msg) or ("SERVICE_UNAVAILABLE" in msg):
            print(f"[efd][WARN] Kudu instável em {kind}; usando -1. Detalhe: {msg[:300]}")
            return -1
        raise


def _digits_only(col):
    """Remove tudo exceto dígitos"""
    return F.regexp_replace(F.trim(col.cast("string")), r"\D", "")


def _mk_kudu_between_where(
    data_inicio: str,
    data_fim: str,
    date_col: str = "dt_doc",
) -> str:
    """
    Gera cláusula WHERE para filtro de período (pushdown Kudu).
    EFD usa dt_doc (DATE) ao invés de TIMESTAMP.
    """
    di = data_inicio.strip()
    df = data_fim.strip()
    return f"({date_col} >= '{di}' AND {date_col} <= '{df}')"


# =============================================================================
# Leitura Kudu EFD
# =============================================================================
def _load_efd_c100(
    spark: SparkSession,
    settings: Settings,
    *,
    data_inicio: str,
    data_fim: str,
    where_extra: Optional[str] = None,
) -> DataFrame:
    """
    Carrega C100 (cabeçalho documento fiscal) do Kudu.
    Aplica pushdown por dt_doc.
    """
    base_where = _mk_kudu_between_where(data_inicio, data_fim, date_col="dt_doc")
    if where_extra:
        final_where = f"({base_where}) AND ({where_extra})"
    else:
        final_where = base_where

    df = read_kudu_efd_c100(
        spark=spark,
        settings=settings,
        where=final_where,
        columns=None,
    )

    return df


def _load_efd_c170(
    spark: SparkSession,
    settings: Settings,
    *,
    data_inicio: str,
    data_fim: str,
    where_extra: Optional[str] = None,
) -> DataFrame:
    """
    Carrega C170 (itens do documento fiscal) do Kudu.
    Aplica pushdown por dt_doc_c100.
    """
    base_where = _mk_kudu_between_where(data_inicio, data_fim, date_col="dt_doc_c100")
    if where_extra:
        final_where = f"({base_where}) AND ({where_extra})"
    else:
        final_where = base_where

    df = read_kudu_efd_c170(
        spark=spark,
        settings=settings,
        where=final_where,
        columns=None,
    )

    return df


# =============================================================================
# Preparação de documentos EFD
# =============================================================================
def _prepare_docs_efd(
    spark: SparkSession,
    settings: Settings,
    *,
    data_inicio: str,
    data_fim: str,
    where_docs: Optional[str],
) -> DataFrame:
    """
    Prepara documentos EFD (C100):
    - Carrega C100
    - Cria chave sintética (empresa_cnpj + dt_doc + num_doc)
    - Normaliza campos emitente/participante
    - Determina lado GO (entrada/saída)
    - Garante flags de eventos
    """
    df = _load_efd_c100(
        spark,
        settings,
        data_inicio=data_inicio,
        data_fim=data_fim,
        where_extra=where_docs,
    ).persist()

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 🔧 CORREÇÃO 3: Chave sintética EFD (alinhado com Django)
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # Django: empresa_cnpj + dt_doc + num_doc formam identificador único
    # Spark: mesma lógica
    df = df.withColumn(
        KEY_COL,
        F.concat_ws(
            "|",
            _digits_only(F.col("cnpj_empresa")),
            F.col("dt_doc").cast("string"),
            F.col("num_doc").cast("string"),
        ),
    )

    # Campos do emitente/escriturador (empresa)
    emit_doc = _digits_only(F.col("cnpj_empresa"))
    emit_uf = F.upper(F.trim(F.col("uf_empresa")))
    emit_ie = _digits_only(F.col("ie_empresa"))
    emit_cmun = _digits_only(F.col("cod_mun_empresa"))

    # Campos do participante (dest ou emit dependendo do ind_oper)
    part_doc = F.coalesce(
        _digits_only(F.col("cnpj_part")),
        _digits_only(F.col("cpf_part")),
    )
    part_uf = F.upper(F.trim(F.col("uf_part")))
    part_ie = _digits_only(F.col("ie_part"))
    part_cmun = _digits_only(F.col("cod_mun_part"))

    # Determina lado GO
    # ind_oper: 0=entrada, 1=saída
    # Para EFD: empresa sempre é GO (Goiás)
    GO = F.lit("GO")

    df = df.withColumn(
        "lado_go",
        F.when(F.col("ind_oper").cast("string") == "1", F.lit("SAIDA"))
        .when(F.col("ind_oper").cast("string") == "0", F.lit("ENTRADA"))
        .otherwise(F.lit(None)),
    )

    # Filtra apenas documentos GO
    df = df.filter(
        (F.col("lado_go").isNotNull())
        & ((emit_uf == GO) | (part_uf == GO)),
    )

    # Data de emissão
    df = df.withColumn("data_emissao_dt", F.col("dt_doc"))

    # Normaliza campos
    df = (
        df.withColumn("emit_doc_ident", emit_doc)
        .withColumn("part_doc_ident", part_doc)
        .withColumn("emit_uf", emit_uf)
        .withColumn("part_uf", part_uf)
        .withColumn("emit_ie", emit_ie)
        .withColumn("part_ie", part_ie)
        .withColumn("emit_cmun", emit_cmun)
        .withColumn("part_cmun", part_cmun)
    )

    # Tipo documento GO (1=saída, 0=entrada)
    df = df.withColumn(
        "tipo_doc_go",
        F.when(F.col("ind_oper").cast("string") == "1", F.lit("1")).otherwise(
            F.lit("0")
        ),
    )

    # Campos de cadastro
    # Saída: empresa é emitente, participante é destinatário
    # Entrada: participante é emitente, empresa é destinatário
    df = df.withColumn(
        "cad_entrada_docnum",
        F.when(F.col("ind_oper").cast("string") == "0", F.col("part_doc_ident")).otherwise(
            F.col("emit_doc_ident")
        ),
    ).withColumn(
        "cad_entrada_ie",
        F.when(F.col("ind_oper").cast("string") == "0", F.col("part_ie")).otherwise(
            F.col("emit_ie")
        ),
    ).withColumn(
        "cad_entrada_cmun_ibge_str",
        F.when(F.col("ind_oper").cast("string") == "0", F.col("part_cmun")).otherwise(
            F.col("emit_cmun")
        ),
    ).withColumn(
        "cad_entrada_uf_src",
        F.when(F.col("ind_oper").cast("string") == "0", F.col("part_uf")).otherwise(
            F.col("emit_uf")
        ),
    ).withColumn(
        "cad_saida_docnum",
        F.when(F.col("ind_oper").cast("string") == "1", F.col("emit_doc_ident")).otherwise(
            F.col("part_doc_ident")
        ),
    ).withColumn(
        "cad_saida_ie",
        F.when(F.col("ind_oper").cast("string") == "1", F.col("emit_ie")).otherwise(
            F.col("part_ie")
        ),
    ).withColumn(
        "cad_saida_cmun_ibge_str",
        F.when(F.col("ind_oper").cast("string") == "1", F.col("emit_cmun")).otherwise(
            F.col("part_cmun")
        ),
    ).withColumn(
        "cad_saida_uf_src",
        F.when(F.col("ind_oper").cast("string") == "1", F.col("emit_uf")).otherwise(
            F.col("part_uf")
        ),
    )

    # Valor do documento (vl_doc com fallback)
    df = df.withColumn(
        "vl_efd",
        F.coalesce(
            F.col("vl_doc").cast("decimal(17, 2)"),
            F.lit(0).cast("decimal(17, 2)"),
        ),
    )

    # Garante flags de eventos (EFD geralmente não tem eventos, mas mantém compatibilidade)
    if "is_cancelado" not in df.columns:
        df = df.withColumn("is_cancelado", F.lit(False).cast("boolean"))

    if "is_substituido" not in df.columns:
        df = df.withColumn("is_substituido", F.lit(False).cast("boolean"))

    if "has_inutil" not in df.columns:
        df = df.withColumn("has_inutil", F.lit(False).cast("boolean"))

    if "has_cce" not in df.columns:
        df = df.withColumn("has_cce", F.lit(False).cast("boolean"))

    return df


def _prepare_itens_efd(
    spark: SparkSession,
    settings: Settings,
    *,
    data_inicio: str,
    data_fim: str,
    where_itens: Optional[str],
) -> DataFrame:
    """
    Prepara itens EFD (C170):
    - Carrega C170
    - Cria chave sintética (mesma lógica do C100)
    - Normaliza campos ncm, cfop, valores
    """
    df = _load_efd_c170(
        spark,
        settings,
        data_inicio=data_inicio,
        data_fim=data_fim,
        where_extra=where_itens,
    )

    # Cria chave sintética para join com C100
    df = df.withColumn(
        KEY_COL,
        F.concat_ws(
            "|",
            _digits_only(F.col("cnpj_empresa_c100")),
            F.col("dt_doc_c100").cast("string"),
            F.col("num_doc_c100").cast("string"),
        ),
    )

    # Normaliza NCM (8 dígitos)
    if "cod_ncm" in df.columns:
        df = df.withColumn(
            "ncm_norm",
            F.lpad(F.col("cod_ncm").cast("string"), 8, "0"),
        )
    else:
        df = df.withColumn("ncm_norm", F.lit(None).cast("string"))

    # Normaliza CFOP (4 dígitos)
    if "cfop" in df.columns:
        df = df.withColumn(
            "cfop_norm",
            F.lpad(F.col("cfop").cast("string"), 4, "0"),
        )
    else:
        df = df.withColumn("cfop_norm", F.lit(None).cast("string"))

    # Garante valor do item
    # EFD: vl_item ou calcula
    if "vl_item" in df.columns:
        df = df.withColumn("VL_ITEM", F.col("vl_item").cast("decimal(17, 2)"))
    else:
        # Calcula: qtd * vl_unit
        df = df.withColumn(
            "VL_ITEM",
            (
                F.coalesce(F.col("qtd"), F.lit(0)).cast("decimal(17, 2)")
                * F.coalesce(F.col("vl_unit"), F.lit(0)).cast("decimal(17, 2)")
            ),
        )

    # Número do item (sequencial)
    if "num_item" not in df.columns:
        # Se não existir, cria sequencial por documento
        window = Window.partitionBy(KEY_COL).orderBy(F.monotonically_increasing_id())
        df = df.withColumn("num_item", F.row_number().over(window))

    return df


# =============================================================================
# Agregação item→documento
# =============================================================================
def _aggregate_items_to_document_efd(
    df_docs: DataFrame,
    df_itens: DataFrame,
) -> DataFrame:
    """
    Agrega valores de itens para o documento EFD.
    IMPORTANTE: Esta função deve ser chamada DEPOIS de calcular
    o motivo de exclusão do documento (alinhado com Django).

    Agrega:
    - valr_adicionado_operacao: soma de valr_adicionado dos itens participantes
    - qtd_itens: total de itens
    - qtd_itens_participantes: itens com is_cfop_participante=True
    """
    # Agrega itens por documento
    itens_agg = (
        df_itens.groupBy(KEY_COL).agg(
            # Soma valor adicionado apenas dos itens participantes
            F.sum(
                F.when(
                    F.col("is_cfop_participante") == True,  # noqa: E712
                    F.coalesce(F.col("valr_adicionado"), F.lit(0)),
                ).otherwise(F.lit(0))
            )
            .cast("decimal(17, 2)")
            .alias("valr_itens_participantes"),
            # Contadores
            F.count(F.lit(1)).alias("qtd_itens"),
            F.sum(
                F.when(F.col("is_cfop_participante") == True, F.lit(1)).otherwise(  # noqa: E712
                    F.lit(0)
                )
            ).alias("qtd_itens_participantes"),
        )
    )

    # Join com documentos
    df_docs_agg = (
        df_docs.join(itens_agg, on=KEY_COL, how="left")
        .withColumn(
            "valr_adicionado_operacao_items",
            F.coalesce(
                F.col("valr_itens_participantes"),
                F.lit(0).cast("decimal(17, 2)"),
            ),
        )
        .withColumn("qtd_itens", F.coalesce(F.col("qtd_itens"), F.lit(0)))
        .withColumn(
            "qtd_itens_participantes",
            F.coalesce(F.col("qtd_itens_participantes"), F.lit(0)),
        )
        .drop("valr_itens_participantes")
    )

    return df_docs_agg


# =============================================================================
# Motivo de exclusão do documento
# =============================================================================
def _compute_codg_motivo_exclusao_doc_efd(df: DataFrame) -> DataFrame:
    """
    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    🔧 CORREÇÃO: Cálculo do motivo de exclusão do documento
    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    Alinhado com Django (managers.py - DocumentoPartctManager)
    Motivos (ordem de precedência):
    - 10: Documento cancelado (raro em EFD)
    - 13: Documento substituído (raro em EFD)
    - 14: Inutilizado (raro em EFD)
    - 0: Participante

    EFD geralmente não tem eventos, mas mantém compatibilidade.
    Esta função deve ser chamada ANTES de agregar itens→doc!
    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    """
    return df.withColumn(
        "codg_motivo_exclusao_doc",
        F.when(F.col("is_cancelado") == True, F.lit(10))  # noqa: E712
        .when(F.col("is_substituido") == True, F.lit(13))  # noqa: E712
        .when(F.col("has_inutil") == True, F.lit(14))  # noqa: E712
        .otherwise(F.lit(0)),
    ).withColumn(
        "indi_aprop_doc",
        F.when(
            F.col("codg_motivo_exclusao_doc") == F.lit(0),
            F.lit("S"),
        ).otherwise(F.lit("N")),
    )


# =============================================================================
# Projeção final (Iceberg IPM)
# =============================================================================
def _project_document_ipm_efd(
    spark: SparkSession,
    settings: Settings,
    docs_part: DataFrame,
    audit_id: Optional[int],
) -> DataFrame:
    """
    Projeta documento EFD para schema Iceberg IPM.
    Alinha com ipm_documento_partct_calc_ipm.
    """

    def _detect_digits(field_name: str, default: int = 6) -> int:
        """Detecta precisão de campo IBGE no schema Iceberg"""
        full = (
            f"{settings.iceberg.catalog}."
            f"{settings.iceberg.namespace}."
            f"{settings.iceberg.tbl_efd_documento_partct}"
        )
        try:
            schema = spark.table(full).schema
            f = next(
                (x for x in schema.fields if x.name.lower() == field_name.lower()),
                None,
            )
            if f and isinstance(f.dataType, T.DecimalType):
                return 7 if getattr(f.dataType, "precision", 6) >= 7 else 6
        except Exception as e:
            print(f"[proj][efd] Não detectei {field_name}: {e}. Usando {default}.")
        return default

    def _cast_ibge(scol: str, digits: int) -> F.Column:
        return _digits_only(F.col(scol)).cast(f"decimal({digits}, 0)")

    ent_digits = _detect_digits("codg_municipio_entrada_cad", 6)
    sai_digits = _detect_digits("codg_municipio_saida_cad", 6)

    # Referência (AAAAMM)
    docs = docs_part.withColumn(
        "numr_ref_aaaamm",
        F.date_format(F.col("data_emissao_dt"), "yyyyMM").cast("int"),
    )

    # ID processamento
    id_proc = F.lit(int(audit_id) if audit_id is not None else None).cast("decimal(9, 0)")

    # Projeção final
    # EFD usa chave sintética ao invés de chave de acesso
    out = docs.select(
        F.col(KEY_COL).alias("codg_chave_acesso_nfe"),
        F.lit(TIPO_DOCUMENTO_FISCAL_EFD).alias("tipo_documento_fiscal"),
        # ENTRADA
        F.col("cad_entrada_docnum").alias("numr_cpf_cnpj_entrada"),
        F.col("cad_entrada_ie")
        .cast("decimal(15, 0)")
        .alias("numr_inscricao_entrada"),
        F.lit(None).alias("stat_cadastro_entrada"),
        F.lit(None).alias("tipo_enqdto_fiscal_entrada"),
        F.lit(None).alias("indi_prod_rural_entrada"),
        F.lit(None).alias("indi_prod_rural_exclus_entrada"),
        _cast_ibge("cad_entrada_cmun_ibge_str", ent_digits).alias(
            "codg_municipio_entrada_cad"
        ),
        F.col("cad_entrada_uf_src").alias("codg_uf_entrada_cad"),
        _cast_ibge("cad_entrada_cmun_ibge_str", 7).alias(
            "codg_municipio_entrada_doc"
        ),
        F.col("cad_entrada_uf_src").alias("codg_uf_entrada_doc"),
        # SAÍDA
        F.col("cad_saida_docnum").alias("numr_cpf_cnpj_saida"),
        F.col("cad_saida_ie")
        .cast("decimal(14, 0)")
        .alias("numr_inscricao_saida"),
        F.lit(None).alias("stat_cadastro_saida"),
        F.lit(None).alias("tipo_enqdto_fiscal_saida"),
        F.lit(None).alias("indi_prod_rural_saida"),
        F.lit(None).alias("indi_prod_rural_exclus_saida"),
        _cast_ibge("cad_saida_cmun_ibge_str", sai_digits).alias(
            "codg_municipio_saida_cad"
        ),
        F.col("cad_saida_uf_src").alias("codg_uf_saida_cad"),
        _cast_ibge("cad_saida_cmun_ibge_str", 7).alias("codg_municipio_saida_doc"),
        F.col("cad_saida_uf_src").alias("codg_uf_saida_doc"),
        # Datas/valores
        F.col("data_emissao_dt").alias("data_emissao_nfe"),
        F.col("vl_efd").cast("decimal(17, 2)").alias("valr_nota_fiscal"),
        # Regras documento
        F.col("valr_adicionado_operacao")
        .cast("decimal(17, 2)")
        .alias("valr_adicionado_operacao"),
        F.col("indi_aprop_doc").alias("indi_aprop"),
        F.lit(TIPO_DOC_PARTCT_EFD)
        .cast("decimal(3, 0)")
        .alias("codg_tipo_doc_partct_calc"),
        F.col("codg_motivo_exclusao_doc")
        .cast("decimal(2, 0)")
        .alias("codg_motivo_exclusao_calculo"),
        # Referência e auditoria
        F.col("numr_ref_aaaamm")
        .cast("decimal(6, 0)")
        .alias("numr_referencia_documento"),
        id_proc.alias("id_procesm_indice"),
    )

    return out


def _project_item_ipm_efd(
    spark: SparkSession,
    settings: Settings,
    itens_part: DataFrame,
    audit_id: Optional[int],
) -> DataFrame:
    """
    Projeta itens EFD para schema Iceberg IPM.
    Alinha com ipm_item_documento_partct_calc_ipm.
    """
    id_proc = F.lit(int(audit_id) if audit_id is not None else None).cast("decimal(9, 0)")

    out = itens_part.select(
        F.col(KEY_COL).alias("codg_chave_acesso_nfe"),
        F.coalesce(F.col("num_item"), F.lit(None))
        .cast("decimal(3, 0)")
        .alias("numr_item_nfe"),
        F.lit(TIPO_DOCUMENTO_FISCAL_EFD).alias("tipo_documento_fiscal"),
        # Produto
        F.coalesce(F.col("ncm_norm"), F.lit(None)).alias("codg_ncm"),
        F.coalesce(F.col("cfop_norm"), F.lit(None)).alias("codg_cfop"),
        # Valores
        F.coalesce(F.col("VL_ITEM"), F.lit(0))
        .cast("decimal(17, 2)")
        .alias("valr_item"),
        F.coalesce(F.col("valr_adicionado"), F.lit(0))
        .cast("decimal(17, 2)")
        .alias("valr_adicionado"),
        # Regras item
        F.coalesce(F.col("codg_tipo_doc_partct_item"), F.lit(None))
        .cast("decimal(3, 0)")
        .alias("codg_tipo_doc_partct_item"),
        F.coalesce(F.col("is_cfop_participante"), F.lit(False))
        .cast("boolean")
        .alias("is_cfop_participante"),
        F.coalesce(F.col("is_ncm_participante"), F.lit(False))
        .cast("boolean")
        .alias("is_ncm_participante"),
        F.coalesce(F.col("is_monofasico"), F.lit(None))
        .cast("boolean")
        .alias("is_monofasico"),
        # Auditoria
        id_proc.alias("id_procesm_indice"),
    )

    return out


# =============================================================================
# Pipeline principal EFD
# =============================================================================
def run_efd(
    spark: SparkSession,
    settings: Settings,
    *,
    data_inicio: str,
    data_fim: str,
    where_docs: Optional[str],
    where_itens: Optional[str],
    prefer_day_partition: bool,
    audit_params: Optional[Dict] = None,
    audit_enabled: bool = True,
) -> Dict[str, int]:
    """
    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    Pipeline EFD CORRIGIDO (Migração Django→Spark)
    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    Fluxo CORRETO:
    1. Carrega documentos (C100) + itens (C170) do Kudu
    2. Cria chave sintética (empresa_cnpj + dt_doc + num_doc)
    3. Aplica regras de negócio (CFOP, NCM em itens)
    4. ✅ Garante flags de eventos
    5. ✅ Calcula motivo de exclusão do documento ANTES de agregar
    6. ✅ Agrega itens→doc
    7. ✅ Zera valr_adicionado quando motivo != 0
    8. Filtra participantes (motivo == 0)
    9. Projeta para schema Iceberg IPM
    10. Grava com MERGE (upsert por chave sintética)
    11. Auditoria completa

    Retorna: Dict com métricas
    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    """
    audit = None
    if audit_enabled:
        audit = start_and_get_id(
            spark,
            settings,
            documento="EFD",
            data_inicio=data_inicio,
            data_fim=data_fim,
            params_json=json.dumps(
                audit_params or {"fonte": "KUDU"},
                ensure_ascii=False,
            ),
        )

    try:
        # 1) Carrega documentos + itens
        df_docs_base = _prepare_docs_efd(
            spark,
            settings,
            data_inicio=data_inicio,
            data_fim=data_fim,
            where_docs=where_docs,
        ).persist()

        df_itens_base = _prepare_itens_efd(
            spark,
            settings,
            data_inicio=data_inicio,
            data_fim=data_fim,
            where_itens=where_itens,
        ).persist()

        metrics: Dict[str, int] = {}
        metrics["docs_lidos"] = _safe_count(df_docs_base, kind="docs_lidos")
        metrics["itens_lidos"] = _safe_count(df_itens_base, kind="itens_lidos")

        if audit_enabled and audit is not None:
            bump_counts(
                spark,
                settings,
                id_procesm_indice=audit,
                add_docs=metrics["docs_lidos"] if metrics["docs_lidos"] >= 0 else 0,
                add_itens=metrics["itens_lidos"] if metrics["itens_lidos"] >= 0 else 0,
            )

        # 2) Carrega contexto de regras (Oracle: params, CFOP, NCM)
        ctx = build_rules_context(
            spark,
            settings,
            broadcast_params_flag=True,
            include_ncm_ref=True,
        )

        # 3) Aplica regras de negócio em itens (CFOP + NCM)
        df_itens_rules, metrics_itens = apply_rules_to_items(
            df_itens_base,
            ctx,
            apply_ncm=True,
            filter_ncm_nonparticipants=False,
            apply_cfop_items=True,
            filter_cfop_nonparticipants_items=False,
        )
        metrics.update(metrics_itens)

        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # 🔧 CORREÇÃO 1/2: Calcula motivo de exclusão ANTES de agregar itens
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # ORDEM CORRETA (Django):
        # 1. Garante flags de eventos (já feito em _prepare_docs_efd)
        # 2. Calcula motivo de exclusão do documento
        # 3. Agrega itens→doc
        # 4. Zera valor se motivo != 0
        df_docs_with_motivo = _compute_codg_motivo_exclusao_doc_efd(df_docs_base)

        # 4) Agrega itens→doc
        df_docs_aggr = _aggregate_items_to_document_efd(
            df_docs_with_motivo,
            df_itens_rules,
        )

        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # 🔧 CORREÇÃO 2/2: Zera valr_adicionado quando motivo != 0
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # Django faz isso em DocumentoPartctManager.calcular_valor_adicionado
        df_docs_final = df_docs_aggr.withColumn(
            "valr_adicionado_operacao",
            F.when(
                F.col("codg_motivo_exclusao_doc") != 0,
                F.lit(0).cast("decimal(17, 2)"),
            ).otherwise(
                F.coalesce(
                    F.col("valr_adicionado_operacao_items"),
                    F.lit(0).cast("decimal(17, 2)"),
                )
            ),
        )

        # 5) Filtra participantes (motivo == 0)
        df_docs_part = df_docs_final.filter(
            F.col("codg_motivo_exclusao_doc") == F.lit(0)
        ).cache()
        df_itens_part = df_itens_rules.filter(
            F.col("is_cfop_participante") == True  # noqa: E712
        ).cache()

        metrics["docs_participantes"] = _safe_count(
            df_docs_part,
            kind="docs_participantes",
        )
        metrics["itens_participantes"] = _safe_count(
            df_itens_part,
            kind="itens_participantes",
        )

        # 6) Projeção IPM
        df_docs_out = _project_document_ipm_efd(
            spark,
            settings,
            df_docs_part,
            audit_id=audit,
        )
        df_itens_out = _project_item_ipm_efd(
            spark,
            settings,
            df_itens_part,
            audit_id=audit,
        )

        # 7) Alinha com schema Iceberg
        def _align_df_to_iceberg_table(df: DataFrame, table_name: str) -> DataFrame:
            full = (
                f"{settings.iceberg.catalog}."
                f"{settings.iceberg.namespace}."
                f"{table_name}"
            )
            try:
                target = spark.table(full).schema
            except Exception as e:
                print(f"[align][efd] Não consegui ler schema de {full}: {e}")
                return df

            cols_lower = {c.lower(): c for c in df.columns}
            cur = df

            for f in target.fields:
                tgt = f.name
                src = cols_lower.get(tgt.lower())

                if src is None:
                    cur = cur.withColumn(tgt, F.lit(None).cast(f.dataType))
                else:
                    if src != tgt:
                        cur = cur.withColumnRenamed(src, tgt)
                    cur = cur.withColumn(tgt, F.col(tgt).cast(f.dataType))

            return cur.select(*[f.name for f in target.fields])

        df_docs_out = _align_df_to_iceberg_table(
            df_docs_out,
            settings.iceberg.tbl_efd_documento_partct,
        )
        df_itens_out = _align_df_to_iceberg_table(
            df_itens_out,
            settings.iceberg.tbl_efd_item_documento,
        )

        metrics["docs_finais"] = _safe_count(df_docs_out, kind="docs_finais")
        metrics["itens_finais"] = _safe_count(df_itens_out, kind="itens_finais")

        # 8) Escrita Iceberg (MERGE por chave sintética)
        write_df(
            df_docs_out,
            settings=settings,
            format="iceberg",
            table=settings.iceberg.tbl_efd_documento_partct,
            mode="merge",
            key_columns=["codg_chave_acesso_nfe"],  # chave sintética
            spark_session=spark,
        )

        write_df(
            df_itens_out,
            settings=settings,
            format="iceberg",
            table=settings.iceberg.tbl_efd_item_documento,
            mode="merge",
            key_columns=["codg_chave_acesso_nfe", "numr_item_nfe"],
            spark_session=spark,
        )

        # 9) Finaliza auditoria
        if audit_enabled and audit is not None:
            finish_success(
                spark,
                settings,
                id_procesm_indice=audit,
                extra_updates={
                    "qtd_docs": metrics["docs_finais"]
                    if metrics["docs_finais"] >= 0
                    else 0,
                    "qtd_itens": metrics["itens_finais"]
                    if metrics["itens_finais"] >= 0
                    else 0,
                },
            )

        return metrics

    except Exception as e:
        if audit_enabled and audit is not None:
            finish_error(
                spark,
                settings,
                id_procesm_indice=audit,
                erro_msg=str(e),
            )
        raise


# =============================================================================
# CLI
# =============================================================================
def _parse_bool(v: str) -> bool:
    return str(v).strip().lower() in {"1", "true", "t", "y", "yes", "sim", "s"}


def parse_args(argv=None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Pipeline EFD (Kudu -> Iceberg)")
    p.add_argument("--data-inicio", required=True, help="AAAA-MM-DD")
    p.add_argument("--data-fim", required=True, help="AAAA-MM-DD")
    p.add_argument("--where-docs", default=None)
    p.add_argument("--where-itens", default=None)
    p.add_argument("--prefer-day-partition", default="false")
    p.add_argument("--print-settings", default="false")
    p.add_argument("--no-audit", action="store_true")
    return p.parse_args(argv)


def main(argv=None) -> None:
    settings = load_settings_from_env()
    spark = build_spark(settings)
    args = parse_args(argv)

    prefer_day_partition = _parse_bool(args.prefer_day_partition)

    if _parse_bool(args.print_settings):
        print_settings(settings)

    metrics = run_efd(
        spark,
        settings,
        data_inicio=args.data_inicio,
        data_fim=args.data_fim,
        where_docs=args.where_docs,
        where_itens=args.where_itens,
        prefer_day_partition=prefer_day_partition,
        audit_params={
            "cli": True,
            "range_where": _mk_kudu_between_where(
                args.data_inicio,
                args.data_fim,
            ),
            "where_docs": args.where_docs,
            "where_itens": args.where_itens,
        },
        audit_enabled=(not args.no_audit),
    )

    print("\n" + "=" * 80)
    print("EFD PIPELINE - MÉTRICAS FINAIS")
    print("=" * 80)
    for k in sorted(metrics.keys()):
        print(f"  {k:30s}: {metrics[k]:>10,}")
    print("=" * 80 + "\n")

    spark.stop()


if __name__ == "__main__":
    main()
