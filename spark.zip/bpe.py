from __future__ import annotations

import argparse
import json
import os
from typing import Dict, List, Optional, Tuple

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql import types as T

from app.settings import Settings, load_settings_from_env, build_spark, print_settings
from app.utils.audit import start_and_get_id, bump_counts, finish_success, finish_error
from app.utils.io import read_kudu_bpe_ident, read_kudu_bpe_itens, write_df
from app.utils.rules import (
    build_rules_context,
    apply_rules_to_items,
    RulesContext,
)

# =============================================================================
# Constantes BPe
# =============================================================================
BPE_MODELO = "63"
TIPO_DOC_PARTCT_BPE = 30
TIPO_DOCUMENTO_FISCAL_BPE = "63"
KEY_COL = "chbpe"
TS_COL = "dhemi"


# =============================================================================
# Helpers
# =============================================================================
def _safe_count(df: DataFrame, *, kind: str = "count") -> int:
    """Count seguro com tratamento de erro Kudu"""
    try:
        return int(df.count())
    except Exception as e:
        msg = str(e)
        if ("Tablet is lagging too much" in msg) or ("SERVICE_UNAVAILABLE" in msg):
            print(f"[bpe][WARN] Kudu instável em {kind}; usando -1. Detalhe: {msg[:300]}")
            return -1
        raise


def _digits_only(col):
    """Remove tudo exceto dígitos"""
    return F.regexp_replace(F.trim(col.cast("string")), r"\D", "")


def _coalesce_doc_number(cnpj, cpf):
    """Retorna CNPJ ou CPF (priorizando CNPJ), apenas dígitos"""
    return F.coalesce(_digits_only(cnpj), _digits_only(cpf))


def _mk_kudu_between_where(
    data_inicio: str,
    data_fim: str,
    chave: Optional[str] = None,
    ts_col: str = TS_COL,
    key_col: str = KEY_COL,
) -> str:
    """Gera cláusula WHERE para filtro de período (pushdown Kudu)"""
    di = f"{data_inicio.strip()} 00:00:00"
    df = f"{data_fim.strip()} 23:59:59"
    base = f"({ts_col} >= '{di}' AND {ts_col} <= '{df}')"
    if chave:
        base += f" AND {key_col} = '{chave.strip()}'"
    return base


# =============================================================================
# Leitura Kudu BPe
# =============================================================================
def _load_bpe_ident(
    spark: SparkSession,
    settings: Settings,
    *,
    data_inicio: str,
    data_fim: str,
    chbpe: Optional[str],
    where_extra: Optional[str] = None,
) -> DataFrame:
    """
    Carrega identificação BPe do Kudu.
    Aplica pushdown por dhemi e filtros adicionais.
    """
    base_where = _mk_kudu_between_where(
        data_inicio,
        data_fim,
        chbpe,
        ts_col=TS_COL,
        key_col=KEY_COL,
    )
    if where_extra:
        final_where = f"({base_where}) AND ({where_extra})"
    else:
        final_where = base_where

    df = read_kudu_bpe_ident(
        spark=spark,
        settings=settings,
        where=final_where,
        columns=None,
    )

    # Filtra modelo 63 e ambiente produção
    df = df.filter(
        (F.col("mod").cast("string") == F.lit(BPE_MODELO))
        & (F.col("tpamb").cast("string") == F.lit("1"))
    )

    return df


def _load_bpe_itens(
    spark: SparkSession,
    settings: Settings,
    *,
    data_inicio: str,
    data_fim: str,
    chbpe: Optional[str],
    where_extra: Optional[str] = None,
) -> DataFrame:
    """
    Carrega itens BPe do Kudu.
    Aplica pushdown por dhemi_doc e filtros adicionais.
    """
    base_where = _mk_kudu_between_where(
        data_inicio,
        data_fim,
        chbpe,
        ts_col="dhemi_doc",  # itens usam dhemi_doc
        key_col=KEY_COL,
    )
    if where_extra:
        final_where = f"({base_where}) AND ({where_extra})"
    else:
        final_where = base_where

    df = read_kudu_bpe_itens(
        spark=spark,
        settings=settings,
        where=final_where,
        columns=None,
    )

    return df


# =============================================================================
# Preparação de documentos BPe
# =============================================================================
def _prepare_docs_bpe(
    spark: SparkSession,
    settings: Settings,
    *,
    data_inicio: str,
    data_fim: str,
    chbpe: Optional[str],
    where_docs: Optional[str],
) -> DataFrame:
    """
    Prepara documentos BPe:
    - Carrega ident
    - Normaliza campos emitente/agência/tomador
    - Determina lado GO (emitente ou tomador)
    - Processa eventos (cancelamento)
    """
    df = _load_bpe_ident(
        spark,
        settings,
        data_inicio=data_inicio,
        data_fim=data_fim,
        chbpe=chbpe,
        where_extra=where_docs,
    ).persist()

    # Campos do emitente
    emit_doc = _coalesce_doc_number(F.col("emit_cnpj"), F.col("emit_cpf"))
    emit_uf = F.upper(F.trim(F.col("emit_uf")))
    emit_ie = _digits_only(F.col("emit_ie"))
    emit_cmun = _digits_only(F.col("emit_cmun"))

    # Campos da agência (se existir)
    ag_doc = _coalesce_doc_number(
        F.col("infpass_ag_cnpj") if "infpass_ag_cnpj" in df.columns else F.lit(None),
        F.col("infpass_ag_cpf") if "infpass_ag_cpf" in df.columns else F.lit(None),
    )
    ag_uf = (
        F.upper(F.trim(F.col("infpass_ag_uf")))
        if "infpass_ag_uf" in df.columns
        else F.lit(None)
    )
    ag_ie = (
        _digits_only(F.col("infpass_ag_ie"))
        if "infpass_ag_ie" in df.columns
        else F.lit(None)
    )
    ag_cmun = (
        _digits_only(F.col("infpass_ag_cmun"))
        if "infpass_ag_cmun" in df.columns
        else F.lit(None)
    )

    # Campos do tomador (se existir)
    tom_doc = _coalesce_doc_number(
        F.col("infpass_tom_cnpj") if "infpass_tom_cnpj" in df.columns else F.lit(None),
        F.col("infpass_tom_cpf") if "infpass_tom_cpf" in df.columns else F.lit(None),
    )
    tom_uf = (
        F.upper(F.trim(F.col("infpass_tom_uf")))
        if "infpass_tom_uf" in df.columns
        else F.lit(None)
    )

    # Determina lado GO
    GO = F.lit("GO")
    lado_go = (
        F.when(emit_uf == GO, F.lit("EMIT"))
        .when(ag_uf == GO, F.lit("AG"))
        .when(tom_uf == GO, F.lit("TOM"))
        .otherwise(F.lit(None))
    )

    df = (
        df.withColumn("data_emissao_dt", F.to_date(F.col(TS_COL)))
        .withColumn("data_emissao_ts", F.to_timestamp(F.col(TS_COL)))
        .withColumn("emit_doc_ident", _digits_only(emit_doc))
        .withColumn("ag_doc_ident", _digits_only(ag_doc))
        .withColumn("tom_doc_ident", _digits_only(tom_doc))
        .withColumn("emit_uf", emit_uf)
        .withColumn("ag_uf", ag_uf)
        .withColumn("tom_uf", tom_uf)
        .withColumn("emit_ie", emit_ie)
        .withColumn("ag_ie", ag_ie)
        .withColumn("emit_cmun", emit_cmun)
        .withColumn("ag_cmun", ag_cmun)
        .withColumn("lado_go", lado_go)
        .filter(F.col("lado_go").isNotNull())
    )

    # Tipo documento GO (1=saída/emitente, 0=entrada/tomador/agência)
    df = df.withColumn(
        "tipo_doc_go",
        F.when(F.col("lado_go") == F.lit("EMIT"), F.lit("1")).otherwise(F.lit("0")),
    )

    # Campos de cadastro
    # Para BPe: entrada pode ser agência ou tomador (prioriza agência)
    df = (
        df.withColumn(
            "cad_entrada_docnum",
            F.coalesce(F.col("ag_doc_ident"), F.col("tom_doc_ident")),
        )
        .withColumn(
            "cad_entrada_ie",
            F.coalesce(F.col("ag_ie"), F.lit(None)),
        )
        .withColumn(
            "cad_entrada_cmun_ibge_str",
            F.coalesce(F.col("ag_cmun"), F.lit(None)),
        )
        .withColumn(
            "cad_entrada_uf_src",
            F.coalesce(F.col("ag_uf"), F.col("tom_uf")),
        )
        .withColumn("cad_saida_docnum", F.col("emit_doc_ident"))
        .withColumn("cad_saida_ie", F.col("emit_ie"))
        .withColumn("cad_saida_cmun_ibge_str", F.col("emit_cmun"))
        .withColumn("cad_saida_uf_src", F.col("emit_uf"))
    )

    # Valor do BPe (vbp com fallback)
    df = df.withColumn(
        "vl_bpe",
        F.coalesce(
            F.col("vbp").cast("decimal(17,2)"),
            F.lit(0).cast("decimal(17,2)"),
        ),
    )

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 🔧 CORREÇÃO 3: Garante flags de eventos antes da agregação
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # BPe tem campo has_evt_cancel (0/1) que deve ser convertido para is_cancelado (boolean)
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    # Converte has_evt_cancel (0/1) → is_cancelado (boolean)
    if "has_evt_cancel" in df.columns:
        df = df.withColumn(
            "is_cancelado",
            F.when(
                F.col("has_evt_cancel").cast("int") > 0,
                F.lit(True),
            ).otherwise(F.lit(False)),
        )
    else:
        df = df.withColumn("is_cancelado", F.lit(False).cast("boolean"))

    # Outras flags (default False)
    if "is_substituido" not in df.columns:
        df = df.withColumn("is_substituido", F.lit(False).cast("boolean"))

    if "has_inutil" not in df.columns:
        df = df.withColumn("has_inutil", F.lit(False).cast("boolean"))

    if "has_cce" not in df.columns:
        df = df.withColumn("has_cce", F.lit(False).cast("boolean"))

    return df


def _prepare_itens_bpe(
    spark: SparkSession,
    settings: Settings,
    *,
    data_inicio: str,
    data_fim: str,
    chbpe: Optional[str],
    where_itens: Optional[str],
) -> DataFrame:
    """
    Prepara itens BPe:
    - Carrega da tabela de itens
    - Normaliza campos ncm, cfop, valores
    """
    df = _load_bpe_itens(
        spark,
        settings,
        data_inicio=data_inicio,
        data_fim=data_fim,
        chbpe=chbpe,
        where_extra=where_itens,
    )

    # Normaliza NCM (8 dígitos)
    if "ncm" in df.columns:
        df = df.withColumn("ncm_norm", F.lpad(F.col("ncm").cast("string"), 8, "0"))
    else:
        df = df.withColumn("ncm_norm", F.lit(None).cast("string"))

    # Normaliza CFOP (4 dígitos)
    if "cfop" in df.columns:
        df = df.withColumn("cfop_norm", F.lpad(F.col("cfop").cast("string"), 4, "0"))
    else:
        df = df.withColumn("cfop_norm", F.lit(None).cast("string"))

    # Garante valor do item
    # BPe: vitem ou calcula a partir de vcomp
    if "vitem" in df.columns:
        df = df.withColumn("VL_ITEM", F.col("vitem").cast("decimal(17,2)"))
    elif "vcomp" in df.columns:
        df = df.withColumn("VL_ITEM", F.col("vcomp").cast("decimal(17,2)"))
    else:
        df = df.withColumn("VL_ITEM", F.lit(0).cast("decimal(17,2)"))

    return df


# =============================================================================
# Agregação item→documento
# =============================================================================
def _aggregate_items_to_document_bpe(
    df_docs: DataFrame,
    df_itens: DataFrame,
) -> DataFrame:
    """
    Agrega valores de itens para o documento BPe.
    IMPORTANTE: Esta função deve ser chamada DEPOIS de calcular
    o motivo de exclusão do documento (alinhado com Django).

    Agrega:
    - valr_adicionado_operacao: soma de valr_adicionado dos itens participantes
    - qtd_itens: total de itens
    - qtd_itens_participantes: itens com is_cfop_participante=True
    """
    # Agrega itens por documento
    itens_agg = (
        df_itens.groupBy(KEY_COL).agg(
            # Soma valor adicionado apenas dos itens participantes
            F.sum(
                F.when(
                    F.col("is_cfop_participante") == True,  # noqa: E712
                    F.coalesce(F.col("valr_adicionado"), F.lit(0)),
                ).otherwise(F.lit(0))
            )
            .cast("decimal(17,2)")
            .alias("valr_itens_participantes"),
            # Contadores
            F.count(F.lit(1)).alias("qtd_itens"),
            F.sum(
                F.when(F.col("is_cfop_participante") == True, F.lit(1)).otherwise(  # noqa: E712
                    F.lit(0)
                )
            ).alias("qtd_itens_participantes"),
        )
    )

    # Join com documentos
    df_docs_agg = (
        df_docs.join(itens_agg, on=KEY_COL, how="left")
        .withColumn(
            "valr_adicionado_operacao_items",
            F.coalesce(
                F.col("valr_itens_participantes"),
                F.lit(0).cast("decimal(17,2)"),
            ),
        )
        .withColumn("qtd_itens", F.coalesce(F.col("qtd_itens"), F.lit(0)))
        .withColumn(
            "qtd_itens_participantes",
            F.coalesce(F.col("qtd_itens_participantes"), F.lit(0)),
        )
        .drop("valr_itens_participantes")
    )

    return df_docs_agg


# =============================================================================
# Motivo de exclusão do documento
# =============================================================================
def _compute_codg_motivo_exclusao_doc_bpe(df: DataFrame) -> DataFrame:
    """
    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    🔧 CORREÇÃO: Cálculo do motivo de exclusão do documento
    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    Alinhado com Django (managers.py - DocumentoPartctManager)
    Motivos (ordem de precedência):
    - 10: Documento cancelado
    - 13: Documento substituído (se existir)
    - 14: Inutilizado (se existir)
    - 0: Participante

    Esta função deve ser chamada ANTES de agregar itens→doc!
    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    """
    return (
        df.withColumn(
            "codg_motivo_exclusao_doc",
            F.when(F.col("is_cancelado") == True, F.lit(10))  # noqa: E712
            .when(F.col("is_substituido") == True, F.lit(13))  # noqa: E712
            .when(F.col("has_inutil") == True, F.lit(14))  # noqa: E712
            .otherwise(F.lit(0)),
        ).withColumn(
            "indi_aprop_doc",
            F.when(
                F.col("codg_motivo_exclusao_doc") == F.lit(0),
                F.lit("S"),
            ).otherwise(F.lit("N")),
        )
    )


# =============================================================================
# Projeção final (Iceberg IPM)
# =============================================================================
def _project_document_ipm_bpe(
    spark: SparkSession,
    settings: Settings,
    docs_part: DataFrame,
    audit_id: Optional[int],
) -> DataFrame:
    """
    Projeta documento BPe para schema Iceberg IPM.
    Alinha com ipm_documento_partct_calc_ipm.
    """

    def _detect_digits(field_name: str, default: int = 6) -> int:
        """Detecta precisão de campo IBGE no schema Iceberg"""
        full = (
            f"{settings.iceberg.catalog}."
            f"{settings.iceberg.namespace}."
            f"{settings.iceberg.tbl_bpe_documento_partct}"
        )
        try:
            schema = spark.table(full).schema
            f = next(
                (x for x in schema.fields if x.name.lower() == field_name.lower()),
                None,
            )
            if f and isinstance(f.dataType, T.DecimalType):
                return 7 if getattr(f.dataType, "precision", 6) >= 7 else 6
        except Exception as e:
            print(f"[proj][bpe] Não detectei {field_name}: {e}. Usando {default}.")
        return default

    def _cast_ibge(scol: str, digits: int) -> F.Column:
        return _digits_only(F.col(scol)).cast(f"decimal({digits},0)")

    ent_digits = _detect_digits("codg_municipio_entrada_cad", 6)
    sai_digits = _detect_digits("codg_municipio_saida_cad", 6)

    # Referência (AAAAMM)
    docs = docs_part.withColumn(
        "numr_ref_aaaamm",
        F.date_format(F.col("data_emissao_dt"), "yyyyMM").cast("int"),
    )

    # ID processamento
    id_proc = F.lit(int(audit_id) if audit_id is not None else None).cast("decimal(9,0)")

    # Projeção final
    out = docs.select(
        F.col(KEY_COL).alias("codg_chave_acesso_nfe"),
        F.lit(TIPO_DOCUMENTO_FISCAL_BPE).alias("tipo_documento_fiscal"),
        # ENTRADA (agência/tomador)
        F.col("cad_entrada_docnum").alias("numr_cpf_cnpj_entrada"),
        F.col("cad_entrada_ie")
        .cast("decimal(15,0)")
        .alias("numr_inscricao_entrada"),
        F.lit(None).alias("stat_cadastro_entrada"),
        F.lit(None).alias("tipo_enqdto_fiscal_entrada"),
        F.lit(None).alias("indi_prod_rural_entrada"),
        F.lit(None).alias("indi_prod_rural_exclus_entrada"),
        _cast_ibge("cad_entrada_cmun_ibge_str", ent_digits).alias(
            "codg_municipio_entrada_cad"
        ),
        F.col("cad_entrada_uf_src").alias("codg_uf_entrada_cad"),
        _cast_ibge("cad_entrada_cmun_ibge_str", 7).alias(
            "codg_municipio_entrada_doc"
        ),
        F.col("cad_entrada_uf_src").alias("codg_uf_entrada_doc"),
        # SAÍDA (emitente)
        F.col("cad_saida_docnum").alias("numr_cpf_cnpj_saida"),
        F.col("cad_saida_ie")
        .cast("decimal(14,0)")
        .alias("numr_inscricao_saida"),
        F.lit(None).alias("stat_cadastro_saida"),
        F.lit(None).alias("tipo_enqdto_fiscal_saida"),
        F.lit(None).alias("indi_prod_rural_saida"),
        F.lit(None).alias("indi_prod_rural_exclus_saida"),
        _cast_ibge("cad_saida_cmun_ibge_str", sai_digits).alias(
            "codg_municipio_saida_cad"
        ),
        F.col("cad_saida_uf_src").alias("codg_uf_saida_cad"),
        _cast_ibge("cad_saida_cmun_ibge_str", 7).alias("codg_municipio_saida_doc"),
        F.col("cad_saida_uf_src").alias("codg_uf_saida_doc"),
        # Datas/valores
        F.col("data_emissao_dt").alias("data_emissao_nfe"),
        F.col("vl_bpe").cast("decimal(17,2)").alias("valr_nota_fiscal"),
        # Regras documento
        F.col("valr_adicionado_operacao")
        .cast("decimal(17,2)")
        .alias("valr_adicionado_operacao"),
        F.col("indi_aprop_doc").alias("indi_aprop"),
        F.lit(TIPO_DOC_PARTCT_BPE)
        .cast("decimal(3,0)")
        .alias("codg_tipo_doc_partct_calc"),
        F.col("codg_motivo_exclusao_doc")
        .cast("decimal(2,0)")
        .alias("codg_motivo_exclusao_calculo"),
        # Referência e auditoria
        F.col("numr_ref_aaaamm")
        .cast("decimal(6,0)")
        .alias("numr_referencia_documento"),
        id_proc.alias("id_procesm_indice"),
    )

    return out


def _project_item_ipm_bpe(
    spark: SparkSession,
    settings: Settings,
    itens_part: DataFrame,
    audit_id: Optional[int],
) -> DataFrame:
    """
    Projeta itens BPe para schema Iceberg IPM.
    Alinha com ipm_item_documento_partct_calc_ipm.
    """
    id_proc = F.lit(int(audit_id) if audit_id is not None else None).cast("decimal(9,0)")

    out = itens_part.select(
        F.col(KEY_COL).alias("codg_chave_acesso_nfe"),
        F.coalesce(F.col("nitem"), F.lit(None))
        .cast("decimal(3,0)")
        .alias("numr_item_nfe"),
        F.lit(TIPO_DOCUMENTO_FISCAL_BPE).alias("tipo_documento_fiscal"),
        # Produto
        F.coalesce(F.col("ncm_norm"), F.lit(None)).alias("codg_ncm"),
        F.coalesce(F.col("cfop_norm"), F.lit(None)).alias("codg_cfop"),
        # Valores
        F.coalesce(F.col("VL_ITEM"), F.lit(0))
        .cast("decimal(17,2)")
        .alias("valr_item"),
        F.coalesce(F.col("valr_adicionado"), F.lit(0))
        .cast("decimal(17,2)")
        .alias("valr_adicionado"),
        # Regras item
        F.coalesce(F.col("codg_tipo_doc_partct_item"), F.lit(None))
        .cast("decimal(3,0)")
        .alias("codg_tipo_doc_partct_item"),
        F.coalesce(F.col("is_cfop_participante"), F.lit(False))
        .cast("boolean")
        .alias("is_cfop_participante"),
        F.coalesce(F.col("is_ncm_participante"), F.lit(False))
        .cast("boolean")
        .alias("is_ncm_participante"),
        F.coalesce(F.col("is_monofasico"), F.lit(None))
        .cast("boolean")
        .alias("is_monofasico"),
        # Auditoria
        id_proc.alias("id_procesm_indice"),
    )

    return out


# =============================================================================
# Pipeline principal BPe
# =============================================================================
def run_bpe(
    spark: SparkSession,
    settings: Settings,
    *,
    data_inicio: str,
    data_fim: str,
    where_docs: Optional[str],
    where_itens: Optional[str],
    prefer_day_partition: bool,
    audit_params: Optional[Dict] = None,
    audit_enabled: bool = True,
    chbpe: Optional[str] = None,
) -> Dict[str, int]:
    """
    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    Pipeline BPe CORRIGIDO (Migração Django→Spark)
    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    Fluxo CORRETO:
    1. Carrega documentos + itens do Kudu
    2. Aplica regras de negócio (CFOP, NCM em itens)
    3. ✅ Garante flags de eventos (has_evt_cancel → is_cancelado)
    4. ✅ Calcula motivo de exclusão do documento ANTES de agregar
    5. ✅ Agrega itens→doc
    6. ✅ Zera valr_adicionado quando motivo != 0
    7. Filtra participantes (motivo == 0)
    8. Projeta para schema Iceberg IPM
    9. Grava com MERGE (upsert por chave)
    10. Auditoria completa

    Retorna: Dict com métricas
    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    """
    audit = None
    if audit_enabled:
        audit = start_and_get_id(
            spark,
            settings,
            documento="BPE",
            data_inicio=data_inicio,
            data_fim=data_fim,
            params_json=json.dumps(
                audit_params or {"fonte": "KUDU"},
                ensure_ascii=False,
            ),
        )

    try:
        # 1) Carrega documentos + itens
        df_docs_base = _prepare_docs_bpe(
            spark,
            settings,
            data_inicio=data_inicio,
            data_fim=data_fim,
            chbpe=chbpe,
            where_docs=where_docs,
        ).persist()

        df_itens_base = _prepare_itens_bpe(
            spark,
            settings,
            data_inicio=data_inicio,
            data_fim=data_fim,
            chbpe=chbpe,
            where_itens=where_itens,
        ).persist()

        metrics: Dict[str, int] = {}
        metrics["docs_lidos"] = _safe_count(df_docs_base, kind="docs_lidos")
        metrics["itens_lidos"] = _safe_count(df_itens_base, kind="itens_lidos")

        if audit_enabled and audit is not None:
            bump_counts(
                spark,
                settings,
                id_procesm_indice=audit,
                add_docs=metrics["docs_lidos"] if metrics["docs_lidos"] >= 0 else 0,
                add_itens=metrics["itens_lidos"] if metrics["itens_lidos"] >= 0 else 0,
            )

        # 2) Carrega contexto de regras (Oracle: params, CFOP, NCM)
        # BPe não usa GEN nem CCE, apenas CFOP e NCM em itens
        ctx = build_rules_context(
            spark,
            settings,
            broadcast_params_flag=True,
            include_ncm_ref=True,
        )

        # 3) Aplica regras de negócio em itens (CFOP + NCM)
        df_itens_rules, metrics_itens = apply_rules_to_items(
            df_itens_base,
            ctx,
            apply_ncm=True,
            filter_ncm_nonparticipants=False,
            apply_cfop_items=True,
            filter_cfop_nonparticipants_items=False,
        )
        metrics.update(metrics_itens)

        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # 🔧 CORREÇÃO 1/2: Calcula motivo de exclusão ANTES de agregar itens
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # ORDEM CORRETA (Django):
        # 1. Garante flags de eventos (já feito em _prepare_docs_bpe)
        # 2. Calcula motivo de exclusão do documento
        # 3. Agrega itens→doc
        # 4. Zera valor se motivo != 0
        df_docs_with_motivo = _compute_codg_motivo_exclusao_doc_bpe(df_docs_base)

        # 4) Agrega itens→doc
        df_docs_aggr = _aggregate_items_to_document_bpe(
            df_docs_with_motivo,
            df_itens_rules,
        )

        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # 🔧 CORREÇÃO 2/2: Zera valr_adicionado quando motivo != 0
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        df_docs_final = df_docs_aggr.withColumn(
            "valr_adicionado_operacao",
            F.when(
                F.col("codg_motivo_exclusao_doc") != 0,
                F.lit(0).cast("decimal(17,2)"),
            ).otherwise(
                F.coalesce(
                    F.col("valr_adicionado_operacao_items"),
                    F.lit(0).cast("decimal(17,2)"),
                )
            ),
        )

        # 5) Filtra participantes (motivo == 0)
        df_docs_part = df_docs_final.filter(
            F.col("codg_motivo_exclusao_doc") == F.lit(0)
        ).cache()
        df_itens_part = df_itens_rules.filter(
            F.col("is_cfop_participante") == True  # noqa: E712
        ).cache()

        metrics["docs_participantes"] = _safe_count(
            df_docs_part,
            kind="docs_participantes",
        )
        metrics["itens_participantes"] = _safe_count(
            df_itens_part,
            kind="itens_participantes",
        )

        # 6) Projeção IPM
        df_docs_out = _project_document_ipm_bpe(
            spark,
            settings,
            df_docs_part,
            audit_id=audit,
        )
        df_itens_out = _project_item_ipm_bpe(
            spark,
            settings,
            df_itens_part,
            audit_id=audit,
        )

        # 7) Alinha com schema Iceberg
        def _align_df_to_iceberg_table(df: DataFrame, table_name: str) -> DataFrame:
            full = (
                f"{settings.iceberg.catalog}."
                f"{settings.iceberg.namespace}."
                f"{table_name}"
            )
            try:
                target = spark.table(full).schema
            except Exception as e:
                print(f"[align][bpe] Não consegui ler schema de {full}: {e}")
                return df

            cols_lower = {c.lower(): c for c in df.columns}
            cur = df

            for f in target.fields:
                tgt = f.name
                src = cols_lower.get(tgt.lower())

                if src is None:
                    cur = cur.withColumn(tgt, F.lit(None).cast(f.dataType))
                else:
                    if src != tgt:
                        cur = cur.withColumnRenamed(src, tgt)
                    cur = cur.withColumn(tgt, F.col(tgt).cast(f.dataType))

            return cur.select(*[f.name for f in target.fields])

        df_docs_out = _align_df_to_iceberg_table(
            df_docs_out,
            settings.iceberg.tbl_bpe_documento_partct,
        )
        df_itens_out = _align_df_to_iceberg_table(
            df_itens_out,
            settings.iceberg.tbl_bpe_item_documento,
        )

        metrics["docs_finais"] = _safe_count(df_docs_out, kind="docs_finais")
        metrics["itens_finais"] = _safe_count(df_itens_out, kind="itens_finais")

        # 8) Escrita Iceberg (MERGE)
        write_df(
            df_docs_out,
            settings=settings,
            format="iceberg",
            table=settings.iceberg.tbl_bpe_documento_partct,
            mode="merge",
            key_columns=["codg_chave_acesso_nfe"],
            spark_session=spark,
        )

        write_df(
            df_itens_out,
            settings=settings,
            format="iceberg",
            table=settings.iceberg.tbl_bpe_item_documento,
            mode="merge",
            key_columns=["codg_chave_acesso_nfe", "numr_item_nfe"],
            spark_session=spark,
        )

        # 9) Finaliza auditoria
        if audit_enabled and audit is not None:
            finish_success(
                spark,
                settings,
                id_procesm_indice=audit,
                extra_updates={
                    "qtd_docs": metrics["docs_finais"]
                    if metrics["docs_finais"] >= 0
                    else 0,
                    "qtd_itens": metrics["itens_finais"]
                    if metrics["itens_finais"] >= 0
                    else 0,
                },
            )

        return metrics

    except Exception as e:
        if audit_enabled and audit is not None:
            finish_error(
                spark,
                settings,
                id_procesm_indice=audit,
                erro_msg=str(e),
            )
        raise


# =============================================================================
# CLI
# =============================================================================
def _parse_bool(v: str) -> bool:
    return str(v).strip().lower() in {"1", "true", "t", "y", "yes", "sim", "s"}


def parse_args(argv=None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Pipeline BP-e (Kudu -> Iceberg)")
    p.add_argument("--data-inicio", required=True, help="AAAA-MM-DD")
    p.add_argument("--data-fim", required=True, help="AAAA-MM-DD")
    p.add_argument("--where-docs", default=None)
    p.add_argument("--where-itens", default=None)
    p.add_argument("--prefer-day-partition", default="false")
    p.add_argument("--print-settings", default="false")
    p.add_argument("--no-audit", action="store_true")
    p.add_argument("--chbpe", default=None)
    return p.parse_args(argv)


def main(argv=None) -> None:
    settings = load_settings_from_env()
    spark = build_spark(settings)
    args = parse_args(argv)

    prefer_day_partition = _parse_bool(args.prefer_day_partition)

    if _parse_bool(args.print_settings):
        print_settings(settings)

    metrics = run_bpe(
        spark,
        settings,
        data_inicio=args.data_inicio,
        data_fim=args.data_fim,
        where_docs=args.where_docs,
        where_itens=args.where_itens,
        prefer_day_partition=prefer_day_partition,
        audit_params={
            "cli": True,
            "range_where": _mk_kudu_between_where(
                args.data_inicio,
                args.data_fim,
                args.chbpe,
            ),
            "where_docs": args.where_docs,
            "where_itens": args.where_itens,
        },
        audit_enabled=(not args.no_audit),
        chbpe=args.chbpe,
    )

    print("\n" + "=" * 80)
    print("BP-e PIPELINE - MÉTRICAS FINAIS")
    print("=" * 80)
    for k in sorted(metrics.keys()):
        print(f"  {k:30s}: {metrics[k]:>10,}")
    print("=" * 80 + "\n")

    spark.stop()


if __name__ == "__main__":
    main()
